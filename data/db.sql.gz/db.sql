# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.6.19)
# Database: freeukgenealogy
# Generation Time: 2014-10-27 16:06:45 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table craft_assetfiles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assetfiles`;

CREATE TABLE `craft_assetfiles` (
  `id` int(11) NOT NULL,
  `sourceId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `kind` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'unknown',
  `width` smallint(6) unsigned DEFAULT NULL,
  `height` smallint(6) unsigned DEFAULT NULL,
  `size` int(11) unsigned DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assetfiles_filename_folderId_unq_idx` (`filename`,`folderId`),
  KEY `craft_assetfiles_sourceId_fk` (`sourceId`),
  KEY `craft_assetfiles_folderId_fk` (`folderId`),
  CONSTRAINT `craft_assetfiles_folderId_fk` FOREIGN KEY (`folderId`) REFERENCES `craft_assetfolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assetfiles_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assetfiles_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_assetsources` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_assetfolders
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assetfolders`;

CREATE TABLE `craft_assetfolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `sourceId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assetfolders_name_parentId_sourceId_unq_idx` (`name`,`parentId`,`sourceId`),
  KEY `craft_assetfolders_parentId_fk` (`parentId`),
  KEY `craft_assetfolders_sourceId_fk` (`sourceId`),
  CONSTRAINT `craft_assetfolders_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_assetsources` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_assetfolders_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `craft_assetfolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_assetfolders` WRITE;
/*!40000 ALTER TABLE `craft_assetfolders` DISABLE KEYS */;

INSERT INTO `craft_assetfolders` (`id`, `parentId`, `sourceId`, `name`, `path`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,NULL,1,'Files','','2014-10-23 14:13:47','2014-10-23 14:13:47','003bb555-5c59-400c-b6c9-8438ebea2ffc');

/*!40000 ALTER TABLE `craft_assetfolders` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_assetindexdata
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assetindexdata`;

CREATE TABLE `craft_assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sourceId` int(10) NOT NULL,
  `offset` int(10) NOT NULL,
  `uri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` int(10) DEFAULT NULL,
  `recordId` int(10) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assetindexdata_sessionId_sourceId_offset_unq_idx` (`sessionId`,`sourceId`,`offset`),
  KEY `craft_assetindexdata_sourceId_fk` (`sourceId`),
  CONSTRAINT `craft_assetindexdata_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_assetsources` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_assetsources
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assetsources`;

CREATE TABLE `craft_assetsources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `sortOrder` tinyint(4) DEFAULT NULL,
  `fieldLayoutId` int(10) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assetsources_name_unq_idx` (`name`),
  KEY `craft_assetsources_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_assetsources_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_assetsources` WRITE;
/*!40000 ALTER TABLE `craft_assetsources` DISABLE KEYS */;

INSERT INTO `craft_assetsources` (`id`, `name`, `type`, `settings`, `sortOrder`, `fieldLayoutId`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'Files','S3','{\"keyId\":\"AKIAIPMWGL6ZTT6SBPPA\",\"secret\":\"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\",\"bucket\":\"supercoolboiler\",\"subfolder\":\"\",\"urlPrefix\":\"http:\\/\\/s3-eu-west-1.amazonaws.com\\/supercoolboiler\\/\",\"expires\":\"\",\"location\":\"eu-west-1\"}',1,21,'2014-10-23 14:13:47','2014-10-23 14:13:47','246692a7-d12c-4a1a-aa58-a097838a3685');

/*!40000 ALTER TABLE `craft_assetsources` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_assettransformindex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assettransformindex`;

CREATE TABLE `craft_assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fileId` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sourceId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT NULL,
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_assettransformindex_sourceId_fileId_location_idx` (`sourceId`,`fileId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_assettransforms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_assettransforms`;

CREATE TABLE `craft_assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mode` enum('stretch','fit','crop') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'center-center',
  `height` int(10) DEFAULT NULL,
  `width` int(10) DEFAULT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quality` int(10) DEFAULT NULL,
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_assettransforms_name_unq_idx` (`name`),
  UNIQUE KEY `craft_assettransforms_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_auditlog
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_auditlog`;

CREATE TABLE `craft_auditlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `origin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `before` text COLLATE utf8_unicode_ci,
  `after` text COLLATE utf8_unicode_ci,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_auditlog_userId_fk` (`userId`),
  CONSTRAINT `craft_auditlog_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_auditlog` WRITE;
/*!40000 ALTER TABLE `craft_auditlog` DISABLE KEYS */;

INSERT INTO `craft_auditlog` (`id`, `userId`, `type`, `origin`, `before`, `after`, `status`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'Entry','admin/entries/blog/new','{\"id\":{\"label\":\"ID\",\"value\":null},\"title\":{\"label\":\"Title\",\"value\":\"Toot\"},\"uri\":{\"label\":\"URI\",\"value\":\"\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"5\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-10-27\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"}}','{\"id\":{\"label\":\"ID\",\"value\":\"6\"},\"title\":{\"label\":\"Title\",\"value\":\"Toot\"},\"uri\":{\"label\":\"URI\",\"value\":\"blog\\/2014\\/10\\/27\\/toot\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"5\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-10-27\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"}}','live','2014-10-27 12:45:24','2014-10-27 12:45:24','fa83e567-1963-4d5e-bbdc-58400cc9b6ae'),
	(2,1,'Entry','admin/entries/blog/6-toot','{\"id\":{\"label\":\"ID\",\"value\":\"6\"},\"title\":{\"label\":\"Title\",\"value\":\"Toot\"},\"uri\":{\"label\":\"URI\",\"value\":\"\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"5\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-10-27\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"}}','{\"id\":{\"label\":\"ID\",\"value\":\"6\"},\"title\":{\"label\":\"Title\",\"value\":\"Toot\"},\"uri\":{\"label\":\"URI\",\"value\":\"blog\\/2014\\/08\\/13\\/toot\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"5\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-08-13\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"}}','pending','2014-10-27 12:45:34','2014-10-27 12:45:34','a5412fef-a431-4dde-9759-2e8e0f74960f'),
	(3,1,'Category','admin/actions/categories/createCategory','{\"id\":{\"label\":\"ID\",\"value\":null}}','{\"id\":{\"label\":\"ID\",\"value\":\"7\"}}','live','2014-10-27 12:51:26','2014-10-27 12:51:26','5bd053f8-a412-4562-8e4f-4df4cb2eac3a'),
	(4,1,'Category','admin/actions/categories/createCategory','{\"id\":{\"label\":\"ID\",\"value\":null}}','{\"id\":{\"label\":\"ID\",\"value\":\"8\"}}','live','2014-10-27 12:51:30','2014-10-27 12:51:30','9b0305a5-d5e9-4f4b-ba86-aaef9a8d33e1'),
	(5,1,'Category','admin/actions/categories/createCategory','{\"id\":{\"label\":\"ID\",\"value\":null}}','{\"id\":{\"label\":\"ID\",\"value\":\"9\"}}','live','2014-10-27 12:51:31','2014-10-27 12:51:31','4c0d5046-688b-4c4a-b776-1b0446c0ef9d'),
	(6,1,'Entry','admin/entries/blog/6-toot','{\"id\":{\"label\":\"ID\",\"value\":\"6\"},\"title\":{\"label\":\"Title\",\"value\":\"Toot\"},\"uri\":{\"label\":\"URI\",\"value\":\"\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"5\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-08-13\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"},\"blogCategories\":{\"label\":\"Categories\",\"value\":\"\"},\"article\":{\"label\":\"Article\",\"value\":{\"ancestorDist\":null,\"ancestorOf\":null,\"archived\":0,\"dateCreated\":null,\"dateUpdated\":null,\"descendantDist\":null,\"descendantOf\":null,\"fixedOrder\":0,\"id\":null,\"indexBy\":null,\"level\":null,\"limit\":100,\"locale\":\"en_gb\",\"localeEnabled\":1,\"nextSiblingOf\":null,\"offset\":0,\"order\":\"matrixblocks.sortOrder\",\"positionedAfter\":null,\"positionedBefore\":null,\"prevSiblingOf\":null,\"relatedTo\":null,\"ref\":null,\"search\":null,\"siblingOf\":null,\"slug\":null,\"status\":\"enabled\",\"title\":null,\"uri\":null,\"kind\":null,\"childField\":null,\"childOf\":null,\"depth\":null,\"parentField\":null,\"parentOf\":null,\"fieldId\":\"5\",\"ownerId\":\"6\",\"ownerLocale\":null,\"type\":null,\"article\":null,\"blogCategories\":null,\"hideTitle\":null,\"metaDescription\":null,\"metaKeywords\":null,\"pageTitle\":null,\"__criteria__\":\"MatrixBlock\"}},\"metaDescription\":{\"label\":\"Meta Description\",\"value\":\"\"},\"metaKeywords\":{\"label\":\"Meta Keywords\",\"value\":\"\"},\"pageTitle\":{\"label\":\"Page Title\",\"value\":\"\"}}','{\"id\":{\"label\":\"ID\",\"value\":\"6\"},\"title\":{\"label\":\"Title\",\"value\":\"Toot\"},\"uri\":{\"label\":\"URI\",\"value\":\"blog\\/2014\\/08\\/13\\/toot\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"5\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-08-13\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"},\"blogCategories\":{\"label\":\"Categories\",\"value\":\"Data, Something\"},\"article\":{\"label\":\"Article\",\"value\":{\"ancestorDist\":null,\"ancestorOf\":null,\"archived\":0,\"dateCreated\":null,\"dateUpdated\":null,\"descendantDist\":null,\"descendantOf\":null,\"fixedOrder\":0,\"id\":null,\"indexBy\":null,\"level\":null,\"limit\":null,\"locale\":\"en_gb\",\"localeEnabled\":null,\"nextSiblingOf\":null,\"offset\":0,\"order\":\"matrixblocks.sortOrder\",\"positionedAfter\":null,\"positionedBefore\":null,\"prevSiblingOf\":null,\"relatedTo\":null,\"ref\":null,\"search\":null,\"siblingOf\":null,\"slug\":null,\"status\":null,\"title\":null,\"uri\":null,\"kind\":null,\"childField\":null,\"childOf\":null,\"depth\":null,\"parentField\":null,\"parentOf\":null,\"fieldId\":\"5\",\"ownerId\":\"6\",\"ownerLocale\":null,\"type\":null,\"article\":null,\"blogCategories\":null,\"hideTitle\":null,\"metaDescription\":null,\"metaKeywords\":null,\"pageTitle\":null,\"__criteria__\":\"MatrixBlock\"}},\"metaDescription\":{\"label\":\"Meta Description\",\"value\":\"\"},\"metaKeywords\":{\"label\":\"Meta Keywords\",\"value\":\"\"},\"pageTitle\":{\"label\":\"Page Title\",\"value\":\"\"}}','pending','2014-10-27 12:51:43','2014-10-27 12:51:43','4f69de1d-3d6c-4162-b93a-b20b490b4bd2'),
	(7,1,'Entry','admin/entries/blog/new','{\"id\":{\"label\":\"ID\",\"value\":null},\"title\":{\"label\":\"Title\",\"value\":\"Twottle one day might mean something\"},\"uri\":{\"label\":\"URI\",\"value\":\"\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"5\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-10-27\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"},\"blogCategories\":{\"label\":\"Categories\",\"value\":\"\"},\"article\":{\"label\":\"Article\",\"value\":\"\"},\"metaDescription\":{\"label\":\"Meta Description\",\"value\":\"\"},\"metaKeywords\":{\"label\":\"Meta Keywords\",\"value\":\"\"},\"pageTitle\":{\"label\":\"Page Title\",\"value\":\"\"}}','{\"id\":{\"label\":\"ID\",\"value\":\"10\"},\"title\":{\"label\":\"Title\",\"value\":\"Twottle one day might mean something\"},\"uri\":{\"label\":\"URI\",\"value\":\"blog\\/2014\\/10\\/27\\/twottle-one-day-might-mean-something\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"5\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-10-27\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"},\"blogCategories\":{\"label\":\"Categories\",\"value\":\"Data, Else\"},\"article\":{\"label\":\"Article\",\"value\":{\"ancestorDist\":null,\"ancestorOf\":null,\"archived\":0,\"dateCreated\":null,\"dateUpdated\":null,\"descendantDist\":null,\"descendantOf\":null,\"fixedOrder\":0,\"id\":null,\"indexBy\":null,\"level\":null,\"limit\":null,\"locale\":\"en_gb\",\"localeEnabled\":null,\"nextSiblingOf\":null,\"offset\":0,\"order\":\"matrixblocks.sortOrder\",\"positionedAfter\":null,\"positionedBefore\":null,\"prevSiblingOf\":null,\"relatedTo\":null,\"ref\":null,\"search\":null,\"siblingOf\":null,\"slug\":null,\"status\":null,\"title\":null,\"uri\":null,\"kind\":null,\"childField\":null,\"childOf\":null,\"depth\":null,\"parentField\":null,\"parentOf\":null,\"fieldId\":\"5\",\"ownerId\":\"10\",\"ownerLocale\":null,\"type\":null,\"article\":null,\"blogCategories\":null,\"hideTitle\":null,\"metaDescription\":null,\"metaKeywords\":null,\"pageTitle\":null,\"__criteria__\":\"MatrixBlock\"}},\"metaDescription\":{\"label\":\"Meta Description\",\"value\":\"\"},\"metaKeywords\":{\"label\":\"Meta Keywords\",\"value\":\"\"},\"pageTitle\":{\"label\":\"Page Title\",\"value\":\"\"}}','live','2014-10-27 12:52:44','2014-10-27 12:52:44','d956409b-9569-48b4-9ba0-790043bb05ea'),
	(8,1,'Entry','admin/entries/blog/10-twottle-one-day-might-mean-something','{\"id\":{\"label\":\"ID\",\"value\":\"10\"},\"title\":{\"label\":\"Title\",\"value\":\"Twottle one day might mean something\"},\"uri\":{\"label\":\"URI\",\"value\":\"\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"5\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-10-27\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"},\"blogCategories\":{\"label\":\"Categories\",\"value\":\"Data, Else\"},\"article\":{\"label\":\"Article\",\"value\":{\"ancestorDist\":null,\"ancestorOf\":null,\"archived\":0,\"dateCreated\":null,\"dateUpdated\":null,\"descendantDist\":null,\"descendantOf\":null,\"fixedOrder\":0,\"id\":null,\"indexBy\":null,\"level\":null,\"limit\":100,\"locale\":\"en_gb\",\"localeEnabled\":1,\"nextSiblingOf\":null,\"offset\":0,\"order\":\"matrixblocks.sortOrder\",\"positionedAfter\":null,\"positionedBefore\":null,\"prevSiblingOf\":null,\"relatedTo\":null,\"ref\":null,\"search\":null,\"siblingOf\":null,\"slug\":null,\"status\":\"enabled\",\"title\":null,\"uri\":null,\"kind\":null,\"childField\":null,\"childOf\":null,\"depth\":null,\"parentField\":null,\"parentOf\":null,\"fieldId\":\"5\",\"ownerId\":\"10\",\"ownerLocale\":null,\"type\":null,\"article\":null,\"blogCategories\":null,\"hideTitle\":null,\"metaDescription\":null,\"metaKeywords\":null,\"pageTitle\":null,\"__criteria__\":\"MatrixBlock\"}},\"metaDescription\":{\"label\":\"Meta Description\",\"value\":\"\"},\"metaKeywords\":{\"label\":\"Meta Keywords\",\"value\":\"\"},\"pageTitle\":{\"label\":\"Page Title\",\"value\":\"\"}}','{\"id\":{\"label\":\"ID\",\"value\":\"10\"},\"title\":{\"label\":\"Title\",\"value\":\"Twottle one day might mean something\"},\"uri\":{\"label\":\"URI\",\"value\":\"blog\\/2014\\/10\\/27\\/twottle-one-day-might-mean-something\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"5\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-10-27\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"},\"blogCategories\":{\"label\":\"Categories\",\"value\":\"Data, Else\"},\"article\":{\"label\":\"Article\",\"value\":{\"ancestorDist\":null,\"ancestorOf\":null,\"archived\":0,\"dateCreated\":null,\"dateUpdated\":null,\"descendantDist\":null,\"descendantOf\":null,\"fixedOrder\":0,\"id\":null,\"indexBy\":null,\"level\":null,\"limit\":null,\"locale\":\"en_gb\",\"localeEnabled\":null,\"nextSiblingOf\":null,\"offset\":0,\"order\":\"matrixblocks.sortOrder\",\"positionedAfter\":null,\"positionedBefore\":null,\"prevSiblingOf\":null,\"relatedTo\":null,\"ref\":null,\"search\":null,\"siblingOf\":null,\"slug\":null,\"status\":null,\"title\":null,\"uri\":null,\"kind\":null,\"childField\":null,\"childOf\":null,\"depth\":null,\"parentField\":null,\"parentOf\":null,\"fieldId\":\"5\",\"ownerId\":\"10\",\"ownerLocale\":null,\"type\":null,\"article\":null,\"blogCategories\":null,\"hideTitle\":null,\"metaDescription\":null,\"metaKeywords\":null,\"pageTitle\":null,\"__criteria__\":\"MatrixBlock\"}},\"metaDescription\":{\"label\":\"Meta Description\",\"value\":\"\"},\"metaKeywords\":{\"label\":\"Meta Keywords\",\"value\":\"\"},\"pageTitle\":{\"label\":\"Page Title\",\"value\":\"\"}}','pending','2014-10-27 12:54:24','2014-10-27 12:54:24','53b19566-9403-4bb8-a6f9-d95cf8839a3a'),
	(9,1,'Entry','admin/entries/pages/new','{\"id\":{\"label\":\"ID\",\"value\":null},\"title\":{\"label\":\"Title\",\"value\":\"About\"},\"uri\":{\"label\":\"URI\",\"value\":\"\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"3\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-10-27\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"},\"hideTitle\":{\"label\":\"Hide Title\",\"value\":\"\"},\"article\":{\"label\":\"Article\",\"value\":\"\"},\"pageTitle\":{\"label\":\"Page Title\",\"value\":\"\"},\"metaDescription\":{\"label\":\"Meta Description\",\"value\":\"\"},\"metaKeywords\":{\"label\":\"Meta Keywords\",\"value\":\"\"}}','{\"id\":{\"label\":\"ID\",\"value\":\"21\"},\"title\":{\"label\":\"Title\",\"value\":\"About\"},\"uri\":{\"label\":\"URI\",\"value\":\"about\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"3\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-10-27\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"},\"hideTitle\":{\"label\":\"Hide Title\",\"value\":\"No\"},\"article\":{\"label\":\"Article\",\"value\":{\"ancestorDist\":null,\"ancestorOf\":null,\"archived\":0,\"dateCreated\":null,\"dateUpdated\":null,\"descendantDist\":null,\"descendantOf\":null,\"fixedOrder\":0,\"id\":null,\"indexBy\":null,\"level\":null,\"limit\":null,\"locale\":\"en_gb\",\"localeEnabled\":null,\"nextSiblingOf\":null,\"offset\":0,\"order\":\"matrixblocks.sortOrder\",\"positionedAfter\":null,\"positionedBefore\":null,\"prevSiblingOf\":null,\"relatedTo\":null,\"ref\":null,\"search\":null,\"siblingOf\":null,\"slug\":null,\"status\":null,\"title\":null,\"uri\":null,\"kind\":null,\"childField\":null,\"childOf\":null,\"depth\":null,\"parentField\":null,\"parentOf\":null,\"fieldId\":\"5\",\"ownerId\":\"21\",\"ownerLocale\":null,\"type\":null,\"article\":null,\"blogCategories\":null,\"hideTitle\":null,\"menu\":null,\"metaDescription\":null,\"metaKeywords\":null,\"pageTitle\":null,\"__criteria__\":\"MatrixBlock\"}},\"pageTitle\":{\"label\":\"Page Title\",\"value\":\"\"},\"metaDescription\":{\"label\":\"Meta Description\",\"value\":\"\"},\"metaKeywords\":{\"label\":\"Meta Keywords\",\"value\":\"\"}}','live','2014-10-27 15:57:18','2014-10-27 15:57:18','95e2afed-7568-4fee-92ce-92900c0336af'),
	(10,1,'Entry','admin/entries/pages/new','{\"id\":{\"label\":\"ID\",\"value\":null},\"title\":{\"label\":\"Title\",\"value\":\"Support\"},\"uri\":{\"label\":\"URI\",\"value\":\"\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"3\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-10-27\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"},\"hideTitle\":{\"label\":\"Hide Title\",\"value\":\"\"},\"article\":{\"label\":\"Article\",\"value\":\"\"},\"pageTitle\":{\"label\":\"Page Title\",\"value\":\"\"},\"metaDescription\":{\"label\":\"Meta Description\",\"value\":\"\"},\"metaKeywords\":{\"label\":\"Meta Keywords\",\"value\":\"\"}}','{\"id\":{\"label\":\"ID\",\"value\":\"22\"},\"title\":{\"label\":\"Title\",\"value\":\"Support\"},\"uri\":{\"label\":\"URI\",\"value\":\"support\"},\"sectionId\":{\"label\":\"Section\",\"value\":\"3\"},\"postDate\":{\"label\":\"Post Date\",\"value\":\"2014-10-27\"},\"expiryDate\":{\"label\":\"Expiry Date\",\"value\":\"\"},\"hideTitle\":{\"label\":\"Hide Title\",\"value\":\"No\"},\"article\":{\"label\":\"Article\",\"value\":{\"ancestorDist\":null,\"ancestorOf\":null,\"archived\":0,\"dateCreated\":null,\"dateUpdated\":null,\"descendantDist\":null,\"descendantOf\":null,\"fixedOrder\":0,\"id\":null,\"indexBy\":null,\"level\":null,\"limit\":null,\"locale\":\"en_gb\",\"localeEnabled\":null,\"nextSiblingOf\":null,\"offset\":0,\"order\":\"matrixblocks.sortOrder\",\"positionedAfter\":null,\"positionedBefore\":null,\"prevSiblingOf\":null,\"relatedTo\":null,\"ref\":null,\"search\":null,\"siblingOf\":null,\"slug\":null,\"status\":null,\"title\":null,\"uri\":null,\"kind\":null,\"childField\":null,\"childOf\":null,\"depth\":null,\"parentField\":null,\"parentOf\":null,\"fieldId\":\"5\",\"ownerId\":\"22\",\"ownerLocale\":null,\"type\":null,\"article\":null,\"blogCategories\":null,\"hideTitle\":null,\"menu\":null,\"metaDescription\":null,\"metaKeywords\":null,\"pageTitle\":null,\"__criteria__\":\"MatrixBlock\"}},\"pageTitle\":{\"label\":\"Page Title\",\"value\":\"\"},\"metaDescription\":{\"label\":\"Meta Description\",\"value\":\"\"},\"metaKeywords\":{\"label\":\"Meta Keywords\",\"value\":\"\"}}','live','2014-10-27 15:57:24','2014-10-27 15:57:24','032b7a4f-7688-40a5-a8b8-475e0085098f');

/*!40000 ALTER TABLE `craft_auditlog` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_categories`;

CREATE TABLE `craft_categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_categories_groupId_fk` (`groupId`),
  CONSTRAINT `craft_categories_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_categories_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_categories` WRITE;
/*!40000 ALTER TABLE `craft_categories` DISABLE KEYS */;

INSERT INTO `craft_categories` (`id`, `groupId`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(7,1,'2014-10-27 12:51:26','2014-10-27 12:51:26','8dd9c820-3bcd-40b7-8960-869a3de75273'),
	(8,1,'2014-10-27 12:51:30','2014-10-27 12:51:30','180d840d-cc36-4450-8b6c-05daf1157ca8'),
	(9,1,'2014-10-27 12:51:31','2014-10-27 12:51:31','c14b65f1-21b2-4c84-86e9-3ad74d4cee0c');

/*!40000 ALTER TABLE `craft_categories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_categorygroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_categorygroups`;

CREATE TABLE `craft_categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hasUrls` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `template` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_categorygroups_name_unq_idx` (`name`),
  UNIQUE KEY `craft_categorygroups_handle_unq_idx` (`handle`),
  KEY `craft_categorygroups_structureId_fk` (`structureId`),
  KEY `craft_categorygroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_categorygroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_categorygroups_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_categorygroups` WRITE;
/*!40000 ALTER TABLE `craft_categorygroups` DISABLE KEYS */;

INSERT INTO `craft_categorygroups` (`id`, `structureId`, `fieldLayoutId`, `name`, `handle`, `hasUrls`, `template`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,2,24,'Blog','blog',1,'blog/_category','2014-10-27 12:49:01','2014-10-27 12:49:01','8136b837-a620-475d-bdff-0cb0fe490c5d');

/*!40000 ALTER TABLE `craft_categorygroups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_categorygroups_i18n
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_categorygroups_i18n`;

CREATE TABLE `craft_categorygroups_i18n` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `urlFormat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nestedUrlFormat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_categorygroups_i18n_groupId_locale_unq_idx` (`groupId`,`locale`),
  KEY `craft_categorygroups_i18n_locale_fk` (`locale`),
  CONSTRAINT `craft_categorygroups_i18n_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_categorygroups_i18n_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_categorygroups_i18n` WRITE;
/*!40000 ALTER TABLE `craft_categorygroups_i18n` DISABLE KEYS */;

INSERT INTO `craft_categorygroups_i18n` (`id`, `groupId`, `locale`, `urlFormat`, `nestedUrlFormat`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'en_gb','blog/{slug}',NULL,'2014-10-27 12:49:01','2014-10-27 12:49:01','353e619c-a3f4-4157-9df6-8e6bb66378be');

/*!40000 ALTER TABLE `craft_categorygroups_i18n` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_content
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_content`;

CREATE TABLE `craft_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field_hideTitle` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `field_pageTitle` text COLLATE utf8_unicode_ci,
  `field_metaDescription` text COLLATE utf8_unicode_ci,
  `field_metaKeywords` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_content_elementId_locale_unq_idx` (`elementId`,`locale`),
  KEY `craft_content_title_idx` (`title`),
  KEY `craft_content_locale_fk` (`locale`),
  CONSTRAINT `craft_content_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_content_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_content` WRITE;
/*!40000 ALTER TABLE `craft_content` DISABLE KEYS */;

INSERT INTO `craft_content` (`id`, `elementId`, `locale`, `title`, `field_hideTitle`, `field_pageTitle`, `field_metaDescription`, `field_metaKeywords`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'en_gb',NULL,0,NULL,NULL,NULL,'2014-10-23 14:13:21','2014-10-23 14:13:21','11b99189-af8e-435a-9a00-8a04a400488f'),
	(2,2,'en_gb','Home',0,NULL,NULL,NULL,'2014-10-23 14:13:22','2014-10-27 15:45:24','8fab4956-b962-4e9c-afe3-9ba6d6fd289f'),
	(4,4,'en_gb',NULL,0,NULL,NULL,NULL,'2014-10-23 14:13:47','2014-10-23 14:13:47','9fca28e9-15d6-4d5b-91c5-2040dddf72c6'),
	(5,5,'en_gb','Blog',0,NULL,NULL,NULL,'2014-10-27 12:42:18','2014-10-27 15:44:59','00a12aa4-3a81-4714-91fc-fbf8f7e3f417'),
	(6,6,'en_gb','Toot',0,'','','','2014-10-27 12:45:24','2014-10-27 15:44:49','c98c66d5-7658-49b2-b696-77e0b5bfbef7'),
	(7,7,'en_gb','Data',0,NULL,NULL,NULL,'2014-10-27 12:51:26','2014-10-27 12:51:26','2c80caf3-137a-48ec-b201-49eddf50d47a'),
	(8,8,'en_gb','Something',0,NULL,NULL,NULL,'2014-10-27 12:51:30','2014-10-27 12:51:30','6af903a7-9099-45fe-8c33-1f2722ef8fc0'),
	(9,9,'en_gb','Else',0,NULL,NULL,NULL,'2014-10-27 12:51:31','2014-10-27 12:51:31','89582438-2919-4772-8446-a36790631e6f'),
	(10,10,'en_gb','Twottle one day might mean something',0,'','','','2014-10-27 12:52:44','2014-10-27 15:44:49','b08f1ae4-f1b4-40e3-a4a9-c00584697b66'),
	(12,12,'en_gb',NULL,0,NULL,NULL,NULL,'2014-10-27 15:36:31','2014-10-27 15:57:47','1ba16d90-c950-4b27-b4de-55f21f9780d0'),
	(13,13,'en_gb',NULL,0,NULL,NULL,NULL,'2014-10-27 15:36:37','2014-10-27 15:52:01','d8efb1ef-e647-401c-b26d-c7249f945f94'),
	(16,21,'en_gb','About',0,'','','','2014-10-27 15:57:18','2014-10-27 15:57:18','fe6d79b6-1c2d-4c28-947d-77976543eb8b'),
	(17,22,'en_gb','Support',0,'','','','2014-10-27 15:57:24','2014-10-27 15:57:24','3954aa66-8446-4d54-9b4b-e3117c2d8a08');

/*!40000 ALTER TABLE `craft_content` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_deprecationerrors
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_deprecationerrors`;

CREATE TABLE `craft_deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fingerprint` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `line` smallint(6) unsigned NOT NULL,
  `class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `method` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `templateLine` smallint(6) unsigned DEFAULT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `traces` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_deprecationerrors_key_fingerprint_unq_idx` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_elements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_elements`;

CREATE TABLE `craft_elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `archived` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_elements_type_idx` (`type`),
  KEY `craft_elements_enabled_idx` (`enabled`),
  KEY `craft_elements_archived_idx` (`archived`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_elements` WRITE;
/*!40000 ALTER TABLE `craft_elements` DISABLE KEYS */;

INSERT INTO `craft_elements` (`id`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'User',1,0,'2014-10-23 14:13:21','2014-10-23 14:13:21','73d213a5-2f10-4030-985f-5c9ece03e627'),
	(2,'Entry',1,0,'2014-10-23 14:13:22','2014-10-27 15:45:24','a06c2da5-2f03-4399-8ce8-43b4f2ce311a'),
	(4,'GlobalSet',1,0,'2014-10-23 14:13:47','2014-10-23 14:13:47','64e688c3-a36f-477e-bf15-7c6324d83e1b'),
	(5,'Entry',1,0,'2014-10-27 12:42:18','2014-10-27 15:44:59','0bd507e0-10cd-4446-b49f-2e362e383942'),
	(6,'Entry',1,0,'2014-10-27 12:45:24','2014-10-27 15:44:49','5349ee5b-d4a0-47fc-9a69-729faf148780'),
	(7,'Category',1,0,'2014-10-27 12:51:26','2014-10-27 12:51:26','b2e8c924-b3ae-4765-a686-bf165f8fba66'),
	(8,'Category',1,0,'2014-10-27 12:51:30','2014-10-27 12:51:30','32cea345-e73c-446a-9196-e9f8cd9bcb4c'),
	(9,'Category',1,0,'2014-10-27 12:51:31','2014-10-27 12:51:31','f532d37c-5a19-4c0b-9114-554f6c653316'),
	(10,'Entry',1,0,'2014-10-27 12:52:44','2014-10-27 15:44:49','33924905-8930-42b8-8a5d-9dd9eca13bf1'),
	(11,'MatrixBlock',1,0,'2014-10-27 12:52:44','2014-10-27 12:54:24','3c25cf98-7dff-4e06-bb9f-4ba553157be1'),
	(12,'GlobalSet',1,0,'2014-10-27 15:36:31','2014-10-27 15:57:47','001a7a1f-4a9d-40b3-a352-933de1084e7f'),
	(13,'GlobalSet',1,0,'2014-10-27 15:36:37','2014-10-27 15:52:01','adf8cdc0-4616-4252-92f0-404bea11fa4f'),
	(14,'MatrixBlock',1,0,'2014-10-27 15:45:13','2014-10-27 15:52:01','1550aebe-42f4-4cf4-8362-e6eb8dc4e7c1'),
	(15,'MatrixBlock',1,0,'2014-10-27 15:46:22','2014-10-27 15:52:01','c844977c-1e52-41f2-afc7-14fd8ab4be5a'),
	(16,'MatrixBlock',1,0,'2014-10-27 15:46:22','2014-10-27 15:52:01','335ea3fd-9262-4bf5-9cef-f3a5a365ff54'),
	(17,'MatrixBlock',1,0,'2014-10-27 15:57:08','2014-10-27 15:57:47','4c8bceae-bc15-4ecd-9aab-636940d24126'),
	(20,'MatrixBlock',1,0,'2014-10-27 15:57:08','2014-10-27 15:57:47','0c6c3539-8ae9-4573-9ecd-40c7d24d9567'),
	(21,'Entry',1,0,'2014-10-27 15:57:18','2014-10-27 15:57:18','7c34c2c6-aea4-4a14-b018-2f03da05d75f'),
	(22,'Entry',1,0,'2014-10-27 15:57:24','2014-10-27 15:57:24','268b9fc4-f341-4cdb-9a3e-7b78c7b930bb'),
	(23,'MatrixBlock',1,0,'2014-10-27 15:57:47','2014-10-27 15:57:47','d3b6d19f-52bd-4266-b053-a67891a427ae'),
	(24,'MatrixBlock',1,0,'2014-10-27 15:57:47','2014-10-27 15:57:47','b21e19ee-89a2-460a-9db3-1474566699c6');

/*!40000 ALTER TABLE `craft_elements` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_elements_i18n
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_elements_i18n`;

CREATE TABLE `craft_elements_i18n` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_elements_i18n_elementId_locale_unq_idx` (`elementId`,`locale`),
  UNIQUE KEY `craft_elements_i18n_uri_locale_unq_idx` (`uri`,`locale`),
  KEY `craft_elements_i18n_slug_locale_idx` (`slug`,`locale`),
  KEY `craft_elements_i18n_enabled_idx` (`enabled`),
  KEY `craft_elements_i18n_locale_fk` (`locale`),
  CONSTRAINT `craft_elements_i18n_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_elements_i18n_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_elements_i18n` WRITE;
/*!40000 ALTER TABLE `craft_elements_i18n` DISABLE KEYS */;

INSERT INTO `craft_elements_i18n` (`id`, `elementId`, `locale`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'en_gb','',NULL,1,'2014-10-23 14:13:21','2014-10-23 14:13:21','1edc4ec5-64b8-4fcb-b897-96ba3127c783'),
	(2,2,'en_gb','home','__home__',1,'2014-10-23 14:13:22','2014-10-27 15:45:24','159e2132-7323-4e72-95be-bcfb5494af7a'),
	(4,4,'en_gb','',NULL,1,'2014-10-23 14:13:47','2014-10-23 14:13:47','494658f4-95ba-423e-bb7a-a2ebb64f9dd1'),
	(5,5,'en_gb','blog','blog',1,'2014-10-27 12:42:18','2014-10-27 15:44:59','3ecbe76c-6e03-4c83-83d6-39c3e9abaab5'),
	(6,6,'en_gb','toot','blog/2014/08/13/toot',1,'2014-10-27 12:45:24','2014-10-27 15:44:49','0cd2005d-43df-4607-9ce6-d117db5c6d44'),
	(7,7,'en_gb','data','blog/data',1,'2014-10-27 12:51:26','2014-10-27 12:51:26','b267f37e-186c-4e04-81b8-f826f9b25498'),
	(8,8,'en_gb','something','blog/something',1,'2014-10-27 12:51:30','2014-10-27 12:51:30','18ec2023-8fcf-4af4-9c7b-d03e0a04771b'),
	(9,9,'en_gb','else','blog/else',1,'2014-10-27 12:51:31','2014-10-27 12:51:31','1fa84e8a-85ea-48b2-9157-735aa7bec0e9'),
	(10,10,'en_gb','twottle-one-day-might-mean-something','blog/2014/10/27/twottle-one-day-might-mean-something',1,'2014-10-27 12:52:44','2014-10-27 15:44:49','72df051b-a2f9-4a8c-a2e5-31eb8d80c32f'),
	(11,11,'en_gb','',NULL,1,'2014-10-27 12:52:44','2014-10-27 12:54:24','57d892c5-0a92-45c0-88bd-9727536a8862'),
	(13,12,'en_gb','',NULL,1,'2014-10-27 15:36:31','2014-10-27 15:57:47','a01393dd-c646-484d-b394-eddfb3b44e8a'),
	(14,13,'en_gb','',NULL,1,'2014-10-27 15:36:37','2014-10-27 15:52:01','f8a393ca-6eeb-4c57-b708-463b50a11f05'),
	(16,14,'en_gb','',NULL,1,'2014-10-27 15:45:13','2014-10-27 15:52:01','806fc7d3-2c46-44e1-ad61-16b9d7ec1f7a'),
	(18,15,'en_gb','',NULL,1,'2014-10-27 15:46:22','2014-10-27 15:52:01','7680b2a7-ce4c-40f9-89a2-5c2730c17c7b'),
	(19,16,'en_gb','',NULL,1,'2014-10-27 15:46:22','2014-10-27 15:52:01','39d532d2-5e16-45db-b126-e59625750655'),
	(20,17,'en_gb','',NULL,1,'2014-10-27 15:57:08','2014-10-27 15:57:47','a83d2d3b-ac40-49a9-a521-e1f405b9f2a5'),
	(23,20,'en_gb','',NULL,1,'2014-10-27 15:57:08','2014-10-27 15:57:47','56ebfe68-29a0-46dc-b1f4-c546765320b3'),
	(24,21,'en_gb','about','about',1,'2014-10-27 15:57:18','2014-10-27 15:57:18','8a182683-0f11-4144-be93-30887c8d6446'),
	(25,22,'en_gb','support','support',1,'2014-10-27 15:57:24','2014-10-27 15:57:24','0898d155-25a9-4b86-8e2f-347a19bed695'),
	(26,23,'en_gb','',NULL,1,'2014-10-27 15:57:47','2014-10-27 15:57:47','51c0cd20-41fa-48a6-bd86-b4d48a107021'),
	(27,24,'en_gb','',NULL,1,'2014-10-27 15:57:47','2014-10-27 15:57:47','3b032668-6397-487d-abeb-558eb33a9c41');

/*!40000 ALTER TABLE `craft_elements_i18n` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_emailmessages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_emailmessages`;

CREATE TABLE `craft_emailmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` char(150) COLLATE utf8_unicode_ci NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_emailmessages_key_locale_unq_idx` (`key`,`locale`),
  KEY `craft_emailmessages_locale_fk` (`locale`),
  CONSTRAINT `craft_emailmessages_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_entries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entries`;

CREATE TABLE `craft_entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `typeId` int(11) DEFAULT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entries_sectionId_idx` (`sectionId`),
  KEY `craft_entries_typeId_idx` (`typeId`),
  KEY `craft_entries_postDate_idx` (`postDate`),
  KEY `craft_entries_expiryDate_idx` (`expiryDate`),
  KEY `craft_entries_authorId_fk` (`authorId`),
  CONSTRAINT `craft_entries_authorId_fk` FOREIGN KEY (`authorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entries_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_entries` WRITE;
/*!40000 ALTER TABLE `craft_entries` DISABLE KEYS */;

INSERT INTO `craft_entries` (`id`, `sectionId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(2,1,1,NULL,'2014-10-27 15:45:23',NULL,'2014-10-23 14:13:22','2014-10-27 15:45:23','302397ba-9318-4ed8-9b33-2da15ca9069b'),
	(5,4,4,NULL,'2014-10-27 15:44:59',NULL,'2014-10-27 12:42:18','2014-10-27 15:44:59','177e809b-9e62-407a-a7e6-ba5289c2dc3d'),
	(6,5,5,1,'2014-08-13 12:45:00',NULL,'2014-10-27 12:45:24','2014-10-27 12:51:43','8bc9794e-dc3d-4d25-b921-69bf6d87725a'),
	(10,5,5,1,'2014-10-27 12:52:00',NULL,'2014-10-27 12:52:44','2014-10-27 12:54:24','6bb017da-332f-47c8-8227-d59d53042954'),
	(21,3,3,1,'2014-10-27 15:57:18',NULL,'2014-10-27 15:57:18','2014-10-27 15:57:18','cceb9e13-6bd5-422b-ad2b-eb3df45445cc'),
	(22,3,3,1,'2014-10-27 15:57:24',NULL,'2014-10-27 15:57:24','2014-10-27 15:57:24','c24d836f-619a-4d1f-86b6-de5269f0d695');

/*!40000 ALTER TABLE `craft_entries` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_entrydrafts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entrydrafts`;

CREATE TABLE `craft_entrydrafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notes` tinytext COLLATE utf8_unicode_ci,
  `data` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entrydrafts_entryId_locale_idx` (`entryId`,`locale`),
  KEY `craft_entrydrafts_sectionId_fk` (`sectionId`),
  KEY `craft_entrydrafts_creatorId_fk` (`creatorId`),
  KEY `craft_entrydrafts_locale_fk` (`locale`),
  CONSTRAINT `craft_entrydrafts_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_entrydrafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entrydrafts_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_entrytypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entrytypes`;

CREATE TABLE `craft_entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hasTitleField` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `titleLabel` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'Title',
  `titleFormat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sortOrder` tinyint(4) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_entrytypes_name_sectionId_unq_idx` (`name`,`sectionId`),
  UNIQUE KEY `craft_entrytypes_handle_sectionId_unq_idx` (`handle`,`sectionId`),
  KEY `craft_entrytypes_sectionId_fk` (`sectionId`),
  KEY `craft_entrytypes_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_entrytypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entrytypes_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_entrytypes` WRITE;
/*!40000 ALTER TABLE `craft_entrytypes` DISABLE KEYS */;

INSERT INTO `craft_entrytypes` (`id`, `sectionId`, `fieldLayoutId`, `name`, `handle`, `hasTitleField`, `titleLabel`, `titleFormat`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,17,'Homepage','homepage',0,NULL,'{section.name|raw}',NULL,'2014-10-23 14:13:22','2014-10-23 14:13:47','b79b2355-de91-404c-abfb-2c38949b3430'),
	(3,3,19,'Pages','pages',1,'Title',NULL,NULL,'2014-10-23 14:13:47','2014-10-23 14:13:47','5169f97c-a158-4c97-9e14-d5c572ff51c3'),
	(4,4,22,'Blog Frontpage','blogFrontpage',0,NULL,'{section.name|raw}',NULL,'2014-10-27 12:42:18','2014-10-27 12:42:18','2e505531-577c-4a8d-8f7e-ada9f0db7401'),
	(5,5,25,'Blog','blog',1,'Title',NULL,NULL,'2014-10-27 12:43:48','2014-10-27 12:49:49','cfaddcde-cb3c-464e-918c-5db8f6183373');

/*!40000 ALTER TABLE `craft_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_entryversions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_entryversions`;

CREATE TABLE `craft_entryversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryId` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `num` smallint(6) unsigned NOT NULL,
  `notes` tinytext COLLATE utf8_unicode_ci,
  `data` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_entryversions_entryId_locale_idx` (`entryId`,`locale`),
  KEY `craft_entryversions_sectionId_fk` (`sectionId`),
  KEY `craft_entryversions_creatorId_fk` (`creatorId`),
  KEY `craft_entryversions_locale_fk` (`locale`),
  CONSTRAINT `craft_entryversions_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_entryversions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `craft_users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_entryversions_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_entryversions_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_entryversions` WRITE;
/*!40000 ALTER TABLE `craft_entryversions` DISABLE KEYS */;

INSERT INTO `craft_entryversions` (`id`, `entryId`, `sectionId`, `creatorId`, `locale`, `num`, `notes`, `data`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,6,5,1,'en_gb',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"Toot\",\"slug\":\"toot\",\"postDate\":1414413924,\"expiryDate\":null,\"enabled\":1,\"fields\":[]}','2014-10-27 12:45:24','2014-10-27 12:45:24','1d54e724-1d7f-4794-b46e-06d8b0f34111'),
	(2,6,5,1,'en_gb',2,'','{\"typeId\":\"5\",\"authorId\":\"1\",\"title\":\"Toot\",\"slug\":\"toot\",\"postDate\":1407933900,\"expiryDate\":null,\"enabled\":1,\"fields\":[]}','2014-10-27 12:45:34','2014-10-27 12:45:34','e466204a-b405-4543-8ae1-d32bd9e13f2b'),
	(3,6,5,1,'en_gb',3,'','{\"typeId\":\"5\",\"authorId\":\"1\",\"title\":\"Toot\",\"slug\":\"toot\",\"postDate\":1407933900,\"expiryDate\":null,\"enabled\":1,\"fields\":{\"5\":\"\",\"39\":[\"7\",\"8\"],\"37\":\"\",\"38\":\"\",\"36\":\"\"}}','2014-10-27 12:51:43','2014-10-27 12:51:43','430f4119-ae83-416f-aa05-6e9e4b22dfff'),
	(4,10,5,1,'en_gb',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"Twottle one day might mean something\",\"slug\":\"twottle-one-day-might-mean-something\",\"postDate\":1414414364,\"expiryDate\":null,\"enabled\":1,\"fields\":{\"5\":{\"new1\":{\"type\":\"text\",\"enabled\":\"1\",\"fields\":{\"text\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nec enim a nulla laoreet congue pharetra sed mi. Maecenas placerat euismod elit ac tincidunt.<\\/p><p>Morbi varius, nisl sit amet cursus pretium, lorem erat egestas mi, at blandit quam magna non nulla. Mauris dictum fermentum nisl eu sollicitudin. Proin consequat neque massa, at luctus turpis fringilla sit amet. Cras placerat ultricies justo, ut scelerisque quam suscipit et. Duis fermentum ullamcorper lorem non elementum. Nam luctus sagittis elit, vel interdum urna pharetra eget. Integer at diam et felis venenatis egestas.<\\/p><p>Nulla consectetur eu turpis quis vulputate. Nunc facilisis leo sapien, sit amet consectetur mi hendrerit non. Nullam lacinia imperdiet vehicula. Vestibulum iaculis lacus non lorem vehicula condimentum. Nulla vitae aliquet lorem. Vivamus cursus urna porta justo rutrum congue. Aliquam et enim quam. Proin et sollicitudin mi, vitae luctus tortor.<\\/p><p>Proin neque nisl, tempus eu tortor posuere, molestie imperdiet augue. Nullam vel ligula eget ante efficitur bibendum. Fusce convallis, ipsum ac consectetur hendrerit, quam urna convallis nibh, sit amet porttitor purus eros sed lorem. Pellentesque placerat sem eu lorem condimentum, vel dignissim mi tristique.\\r\\nNullam fringilla tellus massa, vitae pharetra orci euismod nec. Suspendisse blandit faucibus justo et vestibulum. Integer semper enim mattis, rutrum justo a, aliquam risus. Cras porta hendrerit ullamcorper.<\\/p><p>Ut sit amet libero efficitur, vestibulum elit sit amet, dictum diam. Mauris fermentum libero ac luctus maximus. Quisque libero augue, dapibus consectetur ullamcorper eu, venenatis non lacus. Morbi tempus lectus sit amet urna dignissim, id pellentesque orci placerat.\\r\\nPellentesque eu porta nibh, a convallis turpis. Vestibulum ac feugiat risus. Cras ac augue magna. Nulla facilisi. Praesent non metus at nisi aliquam euismod vitae quis nisl. Quisque placerat viverra nulla, vitae vestibulum nisi placerat vitae. Praesent tempus laoreet tellus, eget gravida lacus convallis ac. Vestibulum lacinia rutrum lectus sit amet lobortis. Integer tempus tincidunt orci nec sagittis.<\\/p>\",\"textType\":\"\",\"width\":\"two-thirds\"}}},\"39\":[\"7\",\"9\"],\"37\":\"\",\"38\":\"\",\"36\":\"\"}}','2014-10-27 12:52:44','2014-10-27 12:52:44','0aabf252-d951-4808-936d-c7d1f97d88cb'),
	(5,10,5,1,'en_gb',2,'','{\"typeId\":\"5\",\"authorId\":\"1\",\"title\":\"Twottle one day might mean something\",\"slug\":\"twottle-one-day-might-mean-something\",\"postDate\":1414414320,\"expiryDate\":null,\"enabled\":1,\"fields\":{\"5\":{\"11\":{\"type\":\"text\",\"enabled\":\"1\",\"fields\":{\"text\":\"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nec enim a nulla laoreet congue pharetra sed mi. Maecenas placerat euismod elit ac tincidunt.<\\/p><p>Morbi varius, nisl sit amet cursus pretium, lorem erat egestas mi, at blandit quam magna non nulla. Mauris dictum fermentum nisl eu sollicitudin. Proin consequat neque massa, at luctus turpis fringilla sit amet. Cras placerat ultricies justo, ut scelerisque quam suscipit et. Duis fermentum ullamcorper lorem non elementum. Nam luctus sagittis elit, vel interdum urna pharetra eget. Integer at diam et felis venenatis egestas.<\\/p><p>Nulla consectetur eu turpis quis vulputate. Nunc facilisis leo sapien, sit amet consectetur mi hendrerit non. Nullam lacinia imperdiet vehicula. Vestibulum iaculis lacus non lorem vehicula condimentum. Nulla vitae aliquet lorem. Vivamus cursus urna porta justo rutrum congue. Aliquam et enim quam. Proin et sollicitudin mi, vitae luctus tortor.<\\/p><p>Proin neque nisl, tempus eu tortor posuere, molestie imperdiet augue. Nullam vel ligula eget ante efficitur bibendum. Fusce convallis, ipsum ac consectetur hendrerit, quam urna convallis nibh, sit amet porttitor purus eros sed lorem. Pellentesque placerat sem eu lorem condimentum, vel dignissim mi tristique.\\r\\nNullam fringilla tellus massa, vitae pharetra orci euismod nec. Suspendisse blandit faucibus justo et vestibulum. Integer semper enim mattis, rutrum justo a, aliquam risus. Cras porta hendrerit ullamcorper.<\\/p><p>Ut sit amet libero efficitur, vestibulum elit sit amet, dictum diam. Mauris fermentum libero ac luctus maximus. Quisque libero augue, dapibus consectetur ullamcorper eu, venenatis non lacus. Morbi tempus lectus sit amet urna dignissim, id pellentesque orci placerat.\\r\\nPellentesque eu porta nibh, a convallis turpis. Vestibulum ac feugiat risus. Cras ac augue magna. Nulla facilisi. Praesent non metus at nisi aliquam euismod vitae quis nisl. Quisque placerat viverra nulla, vitae vestibulum nisi placerat vitae. Praesent tempus laoreet tellus, eget gravida lacus convallis ac. Vestibulum lacinia rutrum lectus sit amet lobortis. Integer tempus tincidunt orci nec sagittis.<\\/p>\",\"textType\":\"\",\"width\":\"two-thirds\"}}},\"39\":[\"7\",\"9\"],\"37\":\"\",\"38\":\"\",\"36\":\"\"}}','2014-10-27 12:54:24','2014-10-27 12:54:24','986f1139-1d33-4b82-b862-0448cf8c15d0'),
	(6,21,3,1,'en_gb',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"About\",\"slug\":\"about\",\"postDate\":1414425438,\"expiryDate\":null,\"enabled\":1,\"fields\":{\"5\":\"\",\"4\":\"\",\"37\":\"\",\"38\":\"\",\"36\":\"\"}}','2014-10-27 15:57:18','2014-10-27 15:57:18','3df11b9b-5f71-4680-bddf-6552f79a6d11'),
	(7,22,3,1,'en_gb',1,'','{\"typeId\":null,\"authorId\":\"1\",\"title\":\"Support\",\"slug\":\"support\",\"postDate\":1414425444,\"expiryDate\":null,\"enabled\":1,\"fields\":{\"5\":\"\",\"4\":\"\",\"37\":\"\",\"38\":\"\",\"36\":\"\"}}','2014-10-27 15:57:24','2014-10-27 15:57:24','25882113-7347-424c-b05e-1fa9fa426a0d');

/*!40000 ALTER TABLE `craft_entryversions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fieldgroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldgroups`;

CREATE TABLE `craft_fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fieldgroups_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_fieldgroups` WRITE;
/*!40000 ALTER TABLE `craft_fieldgroups` DISABLE KEYS */;

INSERT INTO `craft_fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(2,'Default','2014-10-23 14:13:46','2014-10-23 14:13:46','bdb4a796-5bfa-48bc-8e42-7a02e422fec2'),
	(3,'SEO','2014-10-23 14:13:47','2014-10-23 14:13:47','d5dda5f8-bf75-4809-ac4a-7dbbd81051d7'),
	(4,'Blog','2014-10-27 12:48:21','2014-10-27 12:48:21','1c655bd4-7d7f-4d09-9717-8320a2383945');

/*!40000 ALTER TABLE `craft_fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fieldlayoutfields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldlayoutfields`;

CREATE TABLE `craft_fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) DEFAULT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sortOrder` tinyint(4) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fieldlayoutfields_layoutId_fieldId_unq_idx` (`layoutId`,`fieldId`),
  KEY `craft_fieldlayoutfields_sortOrder_idx` (`sortOrder`),
  KEY `craft_fieldlayoutfields_tabId_fk` (`tabId`),
  KEY `craft_fieldlayoutfields_fieldId_fk` (`fieldId`),
  CONSTRAINT `craft_fieldlayoutfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fieldlayoutfields_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_fieldlayoutfields_tabId_fk` FOREIGN KEY (`tabId`) REFERENCES `craft_fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayoutfields` DISABLE KEYS */;

INSERT INTO `craft_fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(5,6,NULL,6,0,1,'2014-10-23 14:13:46','2014-10-23 14:13:46','6fdc6b58-905e-4fc5-951f-44effb51dd8b'),
	(6,6,NULL,7,0,2,'2014-10-23 14:13:46','2014-10-23 14:13:46','a9f2b568-9f7f-474c-a04b-69cd982ce8ac'),
	(7,6,NULL,8,0,3,'2014-10-23 14:13:46','2014-10-23 14:13:46','7228ddd8-fdde-4e81-a4e3-48ec7b378a57'),
	(8,7,NULL,9,0,1,'2014-10-23 14:13:46','2014-10-23 14:13:46','5ae74e05-365f-4f57-a94d-a0db209d83a4'),
	(9,7,NULL,10,0,2,'2014-10-23 14:13:46','2014-10-23 14:13:46','ba8b8b00-9e00-41cc-b42a-6aa5124154f3'),
	(10,7,NULL,11,0,3,'2014-10-23 14:13:46','2014-10-23 14:13:46','e3e9cc35-1da6-453e-8256-8873ae7b81d4'),
	(11,7,NULL,12,0,4,'2014-10-23 14:13:46','2014-10-23 14:13:46','206203d6-7f84-434c-a723-47fbe396d058'),
	(12,7,NULL,13,0,5,'2014-10-23 14:13:46','2014-10-23 14:13:46','06937195-1ab8-48b7-a461-791e1b1c2c54'),
	(13,8,NULL,14,0,1,'2014-10-23 14:13:46','2014-10-23 14:13:46','64e67e62-4ce8-428f-b58d-cca7dbbfc39a'),
	(14,8,NULL,15,0,2,'2014-10-23 14:13:46','2014-10-23 14:13:46','35d1d17d-08c9-4cae-8eec-cb7725cad82d'),
	(15,8,NULL,16,0,3,'2014-10-23 14:13:46','2014-10-23 14:13:46','654c4e98-f0ba-49f0-a0c0-fd1a69926614'),
	(16,9,NULL,17,0,1,'2014-10-23 14:13:46','2014-10-23 14:13:46','ab791c37-ebbd-40ed-9538-081428ebceb5'),
	(17,9,NULL,18,0,2,'2014-10-23 14:13:46','2014-10-23 14:13:46','b5b9a7e9-9ce1-4a22-89d2-4cedacf4cfc5'),
	(18,10,NULL,19,0,1,'2014-10-23 14:13:46','2014-10-23 14:13:46','b2a279b5-1079-49a5-a022-2d62e28dfdd4'),
	(19,10,NULL,20,0,2,'2014-10-23 14:13:46','2014-10-23 14:13:46','99d57b0e-284d-4c2a-ba13-94882ba8cd6c'),
	(20,11,NULL,21,0,1,'2014-10-23 14:13:46','2014-10-23 14:13:46','4985ab71-d234-47fc-a9bd-f311de9cc084'),
	(21,11,NULL,22,0,2,'2014-10-23 14:13:46','2014-10-23 14:13:46','50297170-4d01-4f73-91ca-2e2554a6f0f7'),
	(22,11,NULL,23,0,3,'2014-10-23 14:13:46','2014-10-23 14:13:46','7033379d-bac0-49a2-80d0-632d6be5fef6'),
	(23,11,NULL,24,0,4,'2014-10-23 14:13:46','2014-10-23 14:13:46','53fa9865-a366-46a3-8b83-19725fde6971'),
	(24,12,NULL,25,0,1,'2014-10-23 14:13:46','2014-10-23 14:13:46','cc57bb3e-e178-4eea-9bab-11e8713ee9c5'),
	(25,12,NULL,26,0,2,'2014-10-23 14:13:46','2014-10-23 14:13:46','af2103b4-0c00-4af5-a374-5ae1fbafc9ae'),
	(26,13,NULL,27,0,1,'2014-10-23 14:13:46','2014-10-23 14:13:46','07fda3db-b3fc-4e5d-9799-7bd315fd5bb4'),
	(27,13,NULL,28,0,2,'2014-10-23 14:13:46','2014-10-23 14:13:46','ca0ea72f-decf-46ad-84d2-af53b37f90e5'),
	(28,14,NULL,29,0,1,'2014-10-23 14:13:46','2014-10-23 14:13:46','a93ffe61-7c1b-4800-94c8-5f6965e6a0ee'),
	(29,14,NULL,30,0,2,'2014-10-23 14:13:46','2014-10-23 14:13:46','916a6352-ded8-49a5-9d8a-69d3b647015f'),
	(30,14,NULL,31,0,3,'2014-10-23 14:13:46','2014-10-23 14:13:46','15bd68ca-7b16-40c8-9956-d8b278682588'),
	(31,14,NULL,32,0,4,'2014-10-23 14:13:46','2014-10-23 14:13:46','45931c02-f60c-43ac-a524-11dbb4090a8a'),
	(32,14,NULL,33,0,5,'2014-10-23 14:13:46','2014-10-23 14:13:46','0fe1dcf7-6ec4-4c97-a165-63e1e7b16328'),
	(33,15,NULL,34,0,1,'2014-10-23 14:13:46','2014-10-23 14:13:46','b09ba9dc-10fd-4463-9193-74faf201305e'),
	(34,16,NULL,35,0,1,'2014-10-23 14:13:47','2014-10-23 14:13:47','9ba3fd40-38ed-45dd-bacd-d4fbbcce46b1'),
	(35,17,3,4,0,1,'2014-10-23 14:13:47','2014-10-23 14:13:47','1277385d-65eb-4fc5-87f2-a4a199c49fde'),
	(36,17,3,5,0,2,'2014-10-23 14:13:47','2014-10-23 14:13:47','32369e9a-3f9e-4571-b907-1fd11e47a2f3'),
	(37,17,4,36,0,1,'2014-10-23 14:13:47','2014-10-23 14:13:47','bbf9c1a9-feca-437f-a2d1-8ed2887dd45b'),
	(38,17,4,37,0,2,'2014-10-23 14:13:47','2014-10-23 14:13:47','98bc978c-ed51-4f0d-ac0a-8103ababa3a4'),
	(39,17,4,38,0,3,'2014-10-23 14:13:47','2014-10-23 14:13:47','7819bba1-680a-41be-a45c-1e789faa9b9b'),
	(40,19,5,4,0,1,'2014-10-23 14:13:47','2014-10-23 14:13:47','3b507c2d-32f0-453a-81e2-4ac1a4b36067'),
	(41,19,5,5,0,2,'2014-10-23 14:13:47','2014-10-23 14:13:47','066bbdd9-eea3-4436-953e-8ed1bb6b5d9e'),
	(42,19,6,36,0,1,'2014-10-23 14:13:47','2014-10-23 14:13:47','e86c52a3-415a-4acf-b3bd-91b9d563a5aa'),
	(43,19,6,37,0,2,'2014-10-23 14:13:47','2014-10-23 14:13:47','c8c9f4dd-d730-4667-9157-72560b10fc39'),
	(44,19,6,38,0,3,'2014-10-23 14:13:47','2014-10-23 14:13:47','1243b9da-6971-418d-9270-8c7a7e11a802'),
	(45,20,NULL,4,0,1,'2014-10-23 14:13:47','2014-10-23 14:13:47','cf46ba50-d032-40b4-9c07-dc948433f4ce'),
	(46,20,NULL,5,0,2,'2014-10-23 14:13:47','2014-10-23 14:13:47','d4274d8f-75d4-44f7-ac4c-6db5e11fc81e'),
	(47,25,7,39,0,1,'2014-10-27 12:49:49','2014-10-27 12:49:49','1acc39d9-ff1d-46ef-99ff-e079aa80d0b8'),
	(48,25,7,5,0,2,'2014-10-27 12:49:49','2014-10-27 12:49:49','0ca79386-6f3a-4cd5-b7b1-9ba64c6dfe24'),
	(49,25,8,37,0,1,'2014-10-27 12:49:49','2014-10-27 12:49:49','5007848a-9307-44b7-99e4-08b181e6ee1b'),
	(50,25,8,38,0,2,'2014-10-27 12:49:49','2014-10-27 12:49:49','fa3ef3dd-496a-4629-8915-3e33dd824eb5'),
	(51,25,8,36,0,3,'2014-10-27 12:49:49','2014-10-27 12:49:49','53ea0a09-019f-425f-a5ad-64a51e0cf326'),
	(56,33,NULL,40,0,1,'2014-10-27 15:43:22','2014-10-27 15:43:22','973a3909-610b-4753-be29-647e74024f32'),
	(57,34,NULL,40,0,1,'2014-10-27 15:43:26','2014-10-27 15:43:26','20131fbe-221f-44f3-9802-10ca52df283d'),
	(63,39,NULL,41,0,1,'2014-10-27 15:51:51','2014-10-27 15:51:51','7cfdc3b3-89c7-449a-89ef-bf7a66b5f6bd'),
	(64,40,NULL,44,0,1,'2014-10-27 15:51:51','2014-10-27 15:51:51','ea428219-bb08-4c50-850a-e46981e2aa3e'),
	(65,40,NULL,42,0,2,'2014-10-27 15:51:51','2014-10-27 15:51:51','397e914a-8ae9-4243-9045-aed0ddeaacea');

/*!40000 ALTER TABLE `craft_fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fieldlayouts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldlayouts`;

CREATE TABLE `craft_fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fieldlayouts_type_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_fieldlayouts` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayouts` DISABLE KEYS */;

INSERT INTO `craft_fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(5,'Entry','2014-10-23 14:13:22','2014-10-23 14:13:22','0dce9a95-32b6-4990-b6d8-0d8663a7850b'),
	(6,'MatrixBlock','2014-10-23 14:13:46','2014-10-23 14:13:46','f759b26d-0d9e-45a6-ad34-d5d11c569130'),
	(7,'MatrixBlock','2014-10-23 14:13:46','2014-10-23 14:13:46','d51afdfa-8bfb-4d5f-84ca-e45580a95da1'),
	(8,'MatrixBlock','2014-10-23 14:13:46','2014-10-23 14:13:46','7f470d78-0d89-4823-a745-5f2338e5463a'),
	(9,'MatrixBlock','2014-10-23 14:13:46','2014-10-23 14:13:46','4ba4c77c-d7d4-48db-848b-8ada208a6998'),
	(10,'MatrixBlock','2014-10-23 14:13:46','2014-10-23 14:13:46','8488f113-35ea-48d5-b335-cb63f56deee0'),
	(11,'MatrixBlock','2014-10-23 14:13:46','2014-10-23 14:13:46','649597f2-269b-47e2-ba12-ccd339682ae4'),
	(12,'MatrixBlock','2014-10-23 14:13:46','2014-10-23 14:13:46','57706542-159d-4f67-a281-82548e911464'),
	(13,'MatrixBlock','2014-10-23 14:13:46','2014-10-23 14:13:46','e76a1470-0e9f-493a-b75a-4bd670ead518'),
	(14,'MatrixBlock','2014-10-23 14:13:46','2014-10-23 14:13:46','0a74d1e3-c3b6-4869-a693-defa230a993e'),
	(15,'MatrixBlock','2014-10-23 14:13:46','2014-10-23 14:13:46','3ae94d19-0b27-4738-816d-cbec0755c90d'),
	(16,'MatrixBlock','2014-10-23 14:13:47','2014-10-23 14:13:47','8076f441-cb6d-44eb-bb06-65d54513c653'),
	(17,'Entry','2014-10-23 14:13:47','2014-10-23 14:13:47','4c961e41-ddee-4884-a6c1-b8035c42c1b2'),
	(19,'Entry','2014-10-23 14:13:47','2014-10-23 14:13:47','c95655d3-610c-48f3-8d04-02eff8ee6f07'),
	(20,'GlobalSet','2014-10-23 14:13:47','2014-10-23 14:13:47','75daf1fb-a810-41de-b083-54f9331f4a04'),
	(21,'Entry','2014-10-23 14:13:47','2014-10-23 14:13:47','854a976a-7b09-4b8b-849c-c58d09b09810'),
	(22,'Entry','2014-10-27 12:42:18','2014-10-27 12:42:18','63c8cd5e-6222-4637-9c57-de9c49fd9d99'),
	(24,'Category','2014-10-27 12:49:01','2014-10-27 12:49:01','6e342a0a-ac88-4fbd-a4df-610f64d7e9d5'),
	(25,'Entry','2014-10-27 12:49:49','2014-10-27 12:49:49','93460fa6-fdc5-4512-b876-8c1dafd0b171'),
	(33,'GlobalSet','2014-10-27 15:43:22','2014-10-27 15:43:22','f06008ed-0e35-469e-9471-58f59762f3ad'),
	(34,'GlobalSet','2014-10-27 15:43:26','2014-10-27 15:43:26','075039c0-7505-445a-b02b-5572b4a3cf1e'),
	(39,'MatrixBlock','2014-10-27 15:51:51','2014-10-27 15:51:51','1b59604f-b466-49fc-aee9-90a66a93e3be'),
	(40,'MatrixBlock','2014-10-27 15:51:51','2014-10-27 15:51:51','61bea1b0-4ed8-4282-8431-93d4ecd52dd5');

/*!40000 ALTER TABLE `craft_fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fieldlayouttabs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fieldlayouttabs`;

CREATE TABLE `craft_fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` tinyint(4) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_fieldlayouttabs_sortOrder_idx` (`sortOrder`),
  KEY `craft_fieldlayouttabs_layoutId_fk` (`layoutId`),
  CONSTRAINT `craft_fieldlayouttabs_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `craft_fieldlayouttabs` DISABLE KEYS */;

INSERT INTO `craft_fieldlayouttabs` (`id`, `layoutId`, `name`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(2,5,'Content',1,'2014-10-23 14:13:22','2014-10-23 14:13:22','36da3f50-3040-4caf-a7c0-6008328b82c2'),
	(3,17,'Article',1,'2014-10-23 14:13:47','2014-10-23 14:13:47','22f60919-cc52-45bb-b30b-f911ff72cd60'),
	(4,17,'SEO',2,'2014-10-23 14:13:47','2014-10-23 14:13:47','dba51531-6bf7-47cf-a08a-8f392e2422ed'),
	(5,19,'Article',1,'2014-10-23 14:13:47','2014-10-23 14:13:47','b8bcc813-4f7d-4122-9f05-9d921af176da'),
	(6,19,'SEO',2,'2014-10-23 14:13:47','2014-10-23 14:13:47','4fa13d94-f50f-42e0-a55e-d1d0166acf06'),
	(7,25,'Post Content',1,'2014-10-27 12:49:49','2014-10-27 12:49:49','08cec494-539f-458c-831e-f832508a27aa'),
	(8,25,'SEO',2,'2014-10-27 12:49:49','2014-10-27 12:49:49','7f34e988-2dfc-4416-9094-f01419b5b0d5');

/*!40000 ALTER TABLE `craft_fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_fields`;

CREATE TABLE `craft_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(58) COLLATE utf8_unicode_ci NOT NULL,
  `context` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'global',
  `instructions` text COLLATE utf8_unicode_ci,
  `translatable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_fields_handle_context_unq_idx` (`handle`,`context`),
  KEY `craft_fields_context_idx` (`context`),
  KEY `craft_fields_groupId_fk` (`groupId`),
  CONSTRAINT `craft_fields_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_fields` WRITE;
/*!40000 ALTER TABLE `craft_fields` DISABLE KEYS */;

INSERT INTO `craft_fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `translatable`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(4,2,'Hide Title','hideTitle','global',NULL,1,'Lightswitch',NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','13de609e-9991-4c23-8f1e-428b941d4356'),
	(5,2,'Article','article','global',NULL,1,'Matrix','{\"maxBlocks\":null}','2014-10-23 14:13:46','2014-10-23 14:13:46','88409c26-4801-434e-82e4-ddec0f51c36d'),
	(6,NULL,'Text','text','matrixBlockType:1',NULL,1,'RichText','{\"configFile\":\"Article.json\"}','2014-10-23 14:13:46','2014-10-23 14:13:46','80ebb988-9cf1-45e5-ac25-367a2f2150e5'),
	(7,NULL,'Type','textType','matrixBlockType:1',NULL,1,'ButtonBox_TextSize','{\"options\":[{\"label\":\"Small\",\"value\":\"smallprint\",\"pxVal\":\"13\"},{\"label\":\"Medium\",\"value\":\"\",\"pxVal\":\"16\",\"default\":1},{\"label\":\"Large\",\"value\":\"lede\",\"pxVal\":\"20\"},{\"label\":\"Mega\",\"value\":\"gamma\",\"pxVal\":\"24\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','7afa3531-a090-4068-9ce5-ee5a6edf62be'),
	(8,NULL,'Width','width','matrixBlockType:1',NULL,1,'ButtonBox_Width','{\"options\":[{\"label\":\"One Third\",\"value\":\"one-third\"},{\"label\":\"Two Thirds\",\"value\":\"two-thirds\",\"default\":1},{\"label\":\"Full Width\",\"value\":\"one-whole\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','41049ce6-1ca0-4b5b-bb31-de8266348e54'),
	(9,NULL,'Link','buttonLink','matrixBlockType:2',NULL,1,'PlainText',NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','a2be95ce-cbe8-4c4d-b1fd-c25941a9ca65'),
	(10,NULL,'Label','label','matrixBlockType:2',NULL,1,'PlainText',NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','dd069cf0-f4cc-4d9a-b2df-24d6b8c68b36'),
	(11,NULL,'Width','width','matrixBlockType:2',NULL,1,'ButtonBox_Width','{\"options\":[{\"label\":\"One Third\",\"value\":\"one-third\",\"default\":1},{\"label\":\"Two Thirds\",\"value\":\"two-thirds\"},{\"label\":\"Full Width\",\"value\":\"one-whole\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','2d34a727-f027-44e2-baac-3ced7da3dbcf'),
	(12,NULL,'Colour','colour','matrixBlockType:2',NULL,1,'ButtonBox_Colours','{\"options\":[{\"label\":\"Red\",\"value\":\"red\",\"cssColour\":\"#d9603b\"},{\"label\":\"Green\",\"value\":\"green\",\"cssColour\":\"#328d7e\",\"default\":1},{\"label\":\"Navy\",\"value\":\"navy\",\"cssColour\":\"#17333a\"},{\"label\":\"Brown\",\"value\":\"brown\",\"cssColour\":\"#818b80\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','fe7a2d88-ed28-4fc0-aa00-4d0ed81b604e'),
	(13,NULL,'Size','weight','matrixBlockType:2',NULL,1,'ButtonBox_TextSize','{\"options\":[{\"label\":\"Small\",\"value\":\"smallprint\",\"pxVal\":\"13\",\"default\":1},{\"label\":\"Medium\",\"value\":\"\",\"pxVal\":\"16\"},{\"label\":\"Large\",\"value\":\"lede\",\"pxVal\":\"20\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','4c8d044f-a597-498c-933c-5acef52145a6'),
	(14,NULL,'Download','file','matrixBlockType:3',NULL,1,'Assets','{\"limit\":1}','2014-10-23 14:13:46','2014-10-23 14:13:46','c5493d21-edc7-49ca-9608-a1be9bc066b6'),
	(15,NULL,'Label','label','matrixBlockType:3',NULL,1,'PlainText',NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','3c07d508-1c40-4d46-970b-5cc485e30c03'),
	(16,NULL,'Width','width','matrixBlockType:3',NULL,1,'ButtonBox_Width','{\"options\":[{\"label\":\"One Third\",\"value\":\"one-third\",\"default\":1},{\"label\":\"Two Thirds\",\"value\":\"two-thirds\"},{\"label\":\"Full Width\",\"value\":\"one-whole\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','2aa5a0bd-c738-4985-bf41-d7c35338c2ed'),
	(17,NULL,'Embed URL','emebdUrl','matrixBlockType:4',NULL,1,'Fetch',NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','fa0f72f3-c3eb-4f4d-ba34-2ebf3e347ca6'),
	(18,NULL,'Width','width','matrixBlockType:4',NULL,1,'ButtonBox_Width','{\"options\":[{\"label\":\"One Third\",\"value\":\"one-third\"},{\"label\":\"Two Thirds\",\"value\":\"two-thirds\",\"default\":1},{\"label\":\"Full Width\",\"value\":\"one-whole\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','662868f4-e409-4fa6-9dca-e23952562166'),
	(19,NULL,'Handle','formHandle','matrixBlockType:5',NULL,1,'PlainText',NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','16a0bfe8-842a-4663-959f-7703d0964d3c'),
	(20,NULL,'Width','width','matrixBlockType:5',NULL,1,'ButtonBox_Width','{\"options\":[{\"label\":\"One Third\",\"value\":\"one-third\"},{\"label\":\"Two Thirds\",\"value\":\"two-thirds\",\"default\":1},{\"label\":\"Full Width\",\"value\":\"one-whole\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','31d6adea-4f9c-468d-b091-e7ab9b927256'),
	(21,NULL,'Heading','heading','matrixBlockType:6',NULL,1,'PlainText',NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','671c14b9-b5f8-45cf-8e2a-30be4f88e8eb'),
	(22,NULL,'Size','fontSize','matrixBlockType:6',NULL,1,'ButtonBox_TextSize','{\"options\":[{\"label\":\"Small\",\"value\":\"small\",\"pxVal\":\"13\"},{\"label\":\"Medium\",\"value\":\"\",\"pxVal\":\"16\",\"default\":1},{\"label\":\"Large\",\"value\":\"large\",\"pxVal\":\"24\"},{\"label\":\"Mega\",\"value\":\"mega\",\"pxVal\":\"32\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','dc61461c-6621-44bd-a1b7-adb90c8e4fb2'),
	(23,NULL,'Align','align','matrixBlockType:6',NULL,1,'ButtonBox_Buttons','{\"options\":[{\"label\":\"Align Left\",\"showLabel\":0,\"value\":\"left\",\"imagePath\":\"\\/admin\\/resources\\/buttonbox\\/images\\/align-left.png\",\"default\":1},{\"label\":\"Align Center\",\"showLabel\":0,\"value\":\"center\",\"imagePath\":\"\\/admin\\/resources\\/buttonbox\\/images\\/align-center.png\"},{\"label\":\"Align Right\",\"showLabel\":0,\"value\":\"right\",\"imagePath\":\"\\/admin\\/resources\\/buttonbox\\/images\\/align-right.png\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','aad13300-e5e3-4afb-9089-d55fdd1056b9'),
	(24,NULL,'Width','width','matrixBlockType:6',NULL,1,'ButtonBox_Width','{\"options\":[{\"label\":\"One Third\",\"value\":\"one-third\"},{\"label\":\"Two Thirds\",\"value\":\"two-thirds\",\"default\":1},{\"label\":\"Full Width\",\"value\":\"one-whole\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','e6d62ef3-9dfb-4cfa-85c8-f8782ec55f7c'),
	(25,NULL,'HTML','html','matrixBlockType:7',NULL,1,'PlainText','{\"multiline\":1,\"initialRows\":4}','2014-10-23 14:13:46','2014-10-23 14:13:46','672c12bb-7b6f-4c63-b7b7-3bba928adaac'),
	(26,NULL,'Width','width','matrixBlockType:7',NULL,1,'ButtonBox_Width','{\"options\":[{\"label\":\"One Third\",\"value\":\"one-third\"},{\"label\":\"Two Thirds\",\"value\":\"two-thirds\",\"default\":1},{\"label\":\"Full Width\",\"value\":\"one-whole\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','9f1dcc79-a5a9-4758-8659-423647161f48'),
	(27,NULL,'Image','image','matrixBlockType:8',NULL,1,'Assets','{\"limit\":1}','2014-10-23 14:13:46','2014-10-23 14:13:46','12821fa6-c89d-4c53-a4d6-6f2b1d92f708'),
	(28,NULL,'Width','width','matrixBlockType:8',NULL,1,'ButtonBox_Width','{\"options\":[{\"label\":\"One Third\",\"value\":\"one-third\"},{\"label\":\"Two Thirds\",\"value\":\"two-thirds\",\"default\":1},{\"label\":\"Full Width\",\"value\":\"one-whole\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','def96476-a7ce-4a8e-823a-aeaf1ecac8f5'),
	(29,NULL,'Quote','quote','matrixBlockType:9',NULL,1,'RichText','{\"configFile\":\"Article.json\"}','2014-10-23 14:13:46','2014-10-23 14:13:46','75bb3228-963c-4f4e-8c38-18efb1e194b1'),
	(30,NULL,'Cite','sourceHeading','matrixBlockType:9',NULL,1,'PlainText',NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','3a47edd9-ef42-43a6-a85d-d658c9c981d6'),
	(31,NULL,'Link','sourceUrl','matrixBlockType:9',NULL,1,'PlainText',NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','f4ded2e4-c823-45f4-a5f7-147e973002a4'),
	(32,NULL,'Size','quoteSize','matrixBlockType:9',NULL,1,'ButtonBox_TextSize','{\"options\":[{\"label\":\"Small\",\"value\":\"\",\"pxVal\":\"13\",\"default\":1},{\"label\":\"Medium\",\"value\":\"medium\",\"pxVal\":\"16\"},{\"label\":\"Large\",\"value\":\"large\",\"pxVal\":\"24\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','25d95156-48f9-4829-b386-9d0ee7b83ded'),
	(33,NULL,'Width','width','matrixBlockType:9',NULL,1,'ButtonBox_Width','{\"options\":[{\"label\":\"One Third\",\"value\":\"one-third\"},{\"label\":\"Two Thirds\",\"value\":\"two-thirds\",\"default\":1},{\"label\":\"Full Width\",\"value\":\"one-whole\"}]}','2014-10-23 14:13:46','2014-10-23 14:13:46','21f9eb63-2b27-4051-afb4-c63ac8928d80'),
	(34,NULL,'Is this Separator visible?','isItVisible','matrixBlockType:10',NULL,1,'Lightswitch',NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','ad9626a7-4397-467b-89bc-6d60949c5cc2'),
	(35,NULL,'Template Handle','templateHandle','matrixBlockType:11',NULL,1,'PlainText',NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','cb0f07bf-2560-4365-afcd-701d7981b6b7'),
	(36,3,'Page Title','pageTitle','global',NULL,1,'PlainText',NULL,'2014-10-23 14:13:47','2014-10-23 14:13:47','a1bbfdfa-abdb-41fe-9716-a5b49c0e7c5a'),
	(37,3,'Meta Description','metaDescription','global',NULL,1,'PlainText',NULL,'2014-10-23 14:13:47','2014-10-23 14:13:47','a05019c6-dccf-47b4-a084-992d04989483'),
	(38,3,'Meta Keywords','metaKeywords','global',NULL,1,'PlainText',NULL,'2014-10-23 14:13:47','2014-10-23 14:13:47','03b34b33-cb50-4e91-a339-c9295559d86e'),
	(39,4,'Categories','blogCategories','global','',0,'Categories','{\"source\":\"group:1\",\"limit\":\"\"}','2014-10-27 12:48:34','2014-10-27 12:49:18','44c0d83c-bc1c-48f3-941a-ed517ed56c12'),
	(40,2,'Menu','menu','global','',0,'Matrix','{\"maxBlocks\":null}','2014-10-27 15:41:40','2014-10-27 15:51:51','6896c291-a5fa-4afb-b4dd-a850bcc49b20'),
	(41,NULL,'Link','internalLink','matrixBlockType:12',NULL,0,'Entries','{\"sources\":\"*\",\"limit\":\"1\"}','2014-10-27 15:41:40','2014-10-27 15:51:51','c66cc9ab-e54e-4816-89b8-ef7bf589c57e'),
	(42,NULL,'URL','linkUrl','matrixBlockType:13',NULL,0,'PlainText','{\"placeholder\":\"\",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2014-10-27 15:41:40','2014-10-27 15:51:51','ca1b184b-7643-4b18-bd9c-8b99cf6361b1'),
	(44,NULL,'Label','label','matrixBlockType:13',NULL,0,'PlainText','{\"placeholder\":\"\",\"maxLength\":\"\",\"multiline\":\"\",\"initialRows\":\"4\"}','2014-10-27 15:51:51','2014-10-27 15:51:51','1d8c14f3-530e-4f93-aa66-dbe305668482');

/*!40000 ALTER TABLE `craft_fields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_globalsets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_globalsets`;

CREATE TABLE `craft_globalsets` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int(10) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_globalsets_name_unq_idx` (`name`),
  UNIQUE KEY `craft_globalsets_handle_unq_idx` (`handle`),
  KEY `craft_globalsets_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_globalsets_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_globalsets_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_globalsets` WRITE;
/*!40000 ALTER TABLE `craft_globalsets` DISABLE KEYS */;

INSERT INTO `craft_globalsets` (`id`, `name`, `handle`, `fieldLayoutId`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(4,'404','fourOhFour',20,'2014-10-23 14:13:47','2014-10-23 14:13:47','8e39e1d4-d1dd-47d9-9215-dca03f03dd65'),
	(12,'Main menu','mainMenu',34,'2014-10-27 15:36:31','2014-10-27 15:43:26','81b71bae-2951-4c2e-9385-cab64e3328f6'),
	(13,'Footer menu','footerMenu',33,'2014-10-27 15:36:37','2014-10-27 15:43:22','53d44b54-1940-4bee-9d68-4a21abaf5dec');

/*!40000 ALTER TABLE `craft_globalsets` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_import_entries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_import_entries`;

CREATE TABLE `craft_import_entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `historyId` int(11) DEFAULT NULL,
  `entryId` int(11) DEFAULT NULL,
  `versionId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_import_entries_historyId_fk` (`historyId`),
  KEY `craft_import_entries_entryId_fk` (`entryId`),
  KEY `craft_import_entries_versionId_fk` (`versionId`),
  CONSTRAINT `craft_import_entries_versionId_fk` FOREIGN KEY (`versionId`) REFERENCES `craft_entryversions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_import_entries_entryId_fk` FOREIGN KEY (`entryId`) REFERENCES `craft_entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_import_entries_historyId_fk` FOREIGN KEY (`historyId`) REFERENCES `craft_import_history` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_import_history
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_import_history`;

CREATE TABLE `craft_import_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rows` int(10) DEFAULT NULL,
  `behavior` enum('append','replace','delete') COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('started','finished','reverted') COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_import_history_userId_fk` (`userId`),
  CONSTRAINT `craft_import_history_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_import_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_import_log`;

CREATE TABLE `craft_import_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `historyId` int(11) DEFAULT NULL,
  `line` int(10) DEFAULT NULL,
  `errors` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_import_log_historyId_fk` (`historyId`),
  CONSTRAINT `craft_import_log_historyId_fk` FOREIGN KEY (`historyId`) REFERENCES `craft_import_history` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_info
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_info`;

CREATE TABLE `craft_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `build` int(11) unsigned NOT NULL,
  `schemaVersion` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `releaseDate` datetime NOT NULL,
  `edition` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `siteName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `siteUrl` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timezone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `maintenance` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `track` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_info` WRITE;
/*!40000 ALTER TABLE `craft_info` DISABLE KEYS */;

INSERT INTO `craft_info` (`id`, `version`, `build`, `schemaVersion`, `releaseDate`, `edition`, `siteName`, `siteUrl`, `timezone`, `on`, `maintenance`, `track`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'2.2',2596,'2.2.1','2014-10-21 20:50:57',2,'Free UK Genealogy','http://freeukgenealogy.craft.dev','UTC',1,0,'stable','2014-10-23 14:13:21','2014-10-23 14:13:29','e50138ec-bed8-4f08-99b5-92ff122955d6');

/*!40000 ALTER TABLE `craft_info` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_locales
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_locales`;

CREATE TABLE `craft_locales` (
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` tinyint(4) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`locale`),
  KEY `craft_locales_sortOrder_idx` (`sortOrder`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_locales` WRITE;
/*!40000 ALTER TABLE `craft_locales` DISABLE KEYS */;

INSERT INTO `craft_locales` (`locale`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	('en_gb',1,'2014-10-23 14:13:21','2014-10-23 14:13:21','868088ae-f740-4efe-96ca-d826d1117414');

/*!40000 ALTER TABLE `craft_locales` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_matrixblocks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixblocks`;

CREATE TABLE `craft_matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) DEFAULT NULL,
  `sortOrder` tinyint(4) DEFAULT NULL,
  `ownerLocale` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_matrixblocks_ownerId_idx` (`ownerId`),
  KEY `craft_matrixblocks_fieldId_idx` (`fieldId`),
  KEY `craft_matrixblocks_typeId_idx` (`typeId`),
  KEY `craft_matrixblocks_sortOrder_idx` (`sortOrder`),
  KEY `craft_matrixblocks_ownerLocale_fk` (`ownerLocale`),
  CONSTRAINT `craft_matrixblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `craft_matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixblocks_ownerLocale_fk` FOREIGN KEY (`ownerLocale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_matrixblocks` WRITE;
/*!40000 ALTER TABLE `craft_matrixblocks` DISABLE KEYS */;

INSERT INTO `craft_matrixblocks` (`id`, `ownerId`, `fieldId`, `typeId`, `sortOrder`, `ownerLocale`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(11,10,5,1,1,'en_gb','2014-10-27 12:52:44','2014-10-27 12:54:24','1149c53f-a4c3-4871-895f-7af5f2af03d2'),
	(14,13,40,12,2,NULL,'2014-10-27 15:45:13','2014-10-27 15:52:01','08189d6c-00dd-458b-a29a-7d292b37e0dc'),
	(15,13,40,12,1,NULL,'2014-10-27 15:46:22','2014-10-27 15:52:01','18aa9b6f-f21a-409b-a327-769b6847529d'),
	(16,13,40,13,3,NULL,'2014-10-27 15:46:22','2014-10-27 15:52:01','1065024d-4aeb-4b78-837e-22ff7ab9861a'),
	(17,12,40,12,1,NULL,'2014-10-27 15:57:08','2014-10-27 15:57:47','5da83a9f-5d82-475c-8ea0-b237dd186f01'),
	(20,12,40,12,4,NULL,'2014-10-27 15:57:08','2014-10-27 15:57:47','06d43b6a-8652-4311-a87b-dc3eb672a1b2'),
	(23,12,40,12,2,NULL,'2014-10-27 15:57:47','2014-10-27 15:57:47','560e3f5a-ec98-48b2-8817-160b9f70c883'),
	(24,12,40,12,3,NULL,'2014-10-27 15:57:47','2014-10-27 15:57:47','e1489a2e-f1e5-49e2-91f7-7fd8a35d7332');

/*!40000 ALTER TABLE `craft_matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_matrixblocktypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixblocktypes`;

CREATE TABLE `craft_matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` tinyint(4) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixblocktypes_name_fieldId_unq_idx` (`name`,`fieldId`),
  UNIQUE KEY `craft_matrixblocktypes_handle_fieldId_unq_idx` (`handle`,`fieldId`),
  KEY `craft_matrixblocktypes_fieldId_fk` (`fieldId`),
  KEY `craft_matrixblocktypes_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_matrixblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `craft_matrixblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `craft_matrixblocktypes` DISABLE KEYS */;

INSERT INTO `craft_matrixblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,5,6,'Text','text',1,'2014-10-23 14:13:46','2014-10-23 14:13:46','5d58d3bb-e316-47dd-b262-ddd0777c5d93'),
	(2,5,7,'Button','button',2,'2014-10-23 14:13:46','2014-10-23 14:13:46','390390ee-235b-4ab1-b341-80e2e90c6ddc'),
	(3,5,8,'Download','download',3,'2014-10-23 14:13:46','2014-10-23 14:13:46','997ba6df-55d1-4e00-a4d2-c200ceda53cc'),
	(4,5,9,'Embed','embed',4,'2014-10-23 14:13:46','2014-10-23 14:13:46','ed415ace-e276-4fbf-8355-0d0e142ac867'),
	(5,5,10,'Form','form',5,'2014-10-23 14:13:46','2014-10-23 14:13:46','336a2731-f98a-4a02-a504-58070934f71a'),
	(6,5,11,'Heading','heading',6,'2014-10-23 14:13:46','2014-10-23 14:13:46','672a58b1-68dd-4559-a2bb-8b053fffc401'),
	(7,5,12,'HTML','html',7,'2014-10-23 14:13:46','2014-10-23 14:13:46','81af4063-3163-483e-a28f-6dc2296d0435'),
	(8,5,13,'Image','image',8,'2014-10-23 14:13:46','2014-10-23 14:13:46','9e17ccea-fca2-4a8c-b8ea-15479e87aaad'),
	(9,5,14,'Quote','quote',9,'2014-10-23 14:13:46','2014-10-23 14:13:46','6342b74f-9aa5-422c-9b8a-4cb841b8b3f6'),
	(10,5,15,'Separator','separator',10,'2014-10-23 14:13:46','2014-10-23 14:13:46','41bc151d-cbc4-43c6-902d-1743515889c8'),
	(11,5,16,'System','system',11,'2014-10-23 14:13:46','2014-10-23 14:13:47','4c9d8d2c-e9aa-4393-bf10-ff6a68ab99f7'),
	(12,40,39,'Internal Link','internalLink',1,'2014-10-27 15:41:40','2014-10-27 15:51:51','ea6c5532-0bf4-4176-a67c-6027d5b6e6c8'),
	(13,40,40,'External Link','externalLink',2,'2014-10-27 15:41:40','2014-10-27 15:51:51','34e5ac10-329f-4fbb-a74c-9edc12c14fe5');

/*!40000 ALTER TABLE `craft_matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_matrixcontent_article
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixcontent_article`;

CREATE TABLE `craft_matrixcontent_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `field_text_text` text COLLATE utf8_unicode_ci,
  `field_text_textType` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `field_text_width` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'two-thirds',
  `field_button_buttonLink` text COLLATE utf8_unicode_ci,
  `field_button_label` text COLLATE utf8_unicode_ci,
  `field_button_width` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'one-third',
  `field_button_colour` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'green',
  `field_button_weight` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'smallprint',
  `field_download_label` text COLLATE utf8_unicode_ci,
  `field_download_width` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'one-third',
  `field_embed_emebdUrl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field_embed_width` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'two-thirds',
  `field_form_formHandle` text COLLATE utf8_unicode_ci,
  `field_form_width` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'two-thirds',
  `field_heading_heading` text COLLATE utf8_unicode_ci,
  `field_heading_fontSize` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `field_heading_align` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'left',
  `field_heading_width` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'two-thirds',
  `field_html_html` text COLLATE utf8_unicode_ci,
  `field_html_width` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'two-thirds',
  `field_image_width` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'two-thirds',
  `field_quote_quote` text COLLATE utf8_unicode_ci,
  `field_quote_sourceHeading` text COLLATE utf8_unicode_ci,
  `field_quote_sourceUrl` text COLLATE utf8_unicode_ci,
  `field_quote_quoteSize` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `field_quote_width` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'two-thirds',
  `field_separator_isItVisible` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `field_system_templateHandle` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixcontent_article_elementId_locale_unq_idx` (`elementId`,`locale`),
  KEY `craft_matrixcontent_article_locale_fk` (`locale`),
  CONSTRAINT `craft_matrixcontent_article_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixcontent_article_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_matrixcontent_article` WRITE;
/*!40000 ALTER TABLE `craft_matrixcontent_article` DISABLE KEYS */;

INSERT INTO `craft_matrixcontent_article` (`id`, `elementId`, `locale`, `field_text_text`, `field_text_textType`, `field_text_width`, `field_button_buttonLink`, `field_button_label`, `field_button_width`, `field_button_colour`, `field_button_weight`, `field_download_label`, `field_download_width`, `field_embed_emebdUrl`, `field_embed_width`, `field_form_formHandle`, `field_form_width`, `field_heading_heading`, `field_heading_fontSize`, `field_heading_align`, `field_heading_width`, `field_html_html`, `field_html_width`, `field_image_width`, `field_quote_quote`, `field_quote_sourceHeading`, `field_quote_sourceUrl`, `field_quote_quoteSize`, `field_quote_width`, `field_separator_isItVisible`, `field_system_templateHandle`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,11,'en_gb','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus nec enim a nulla laoreet congue pharetra sed mi. Maecenas placerat euismod elit ac tincidunt.</p><p>Morbi varius, nisl sit amet cursus pretium, lorem erat egestas mi, at blandit quam magna non nulla. Mauris dictum fermentum nisl eu sollicitudin. Proin consequat neque massa, at luctus turpis fringilla sit amet. Cras placerat ultricies justo, ut scelerisque quam suscipit et. Duis fermentum ullamcorper lorem non elementum. Nam luctus sagittis elit, vel interdum urna pharetra eget. Integer at diam et felis venenatis egestas.</p><p>Nulla consectetur eu turpis quis vulputate. Nunc facilisis leo sapien, sit amet consectetur mi hendrerit non. Nullam lacinia imperdiet vehicula. Vestibulum iaculis lacus non lorem vehicula condimentum. Nulla vitae aliquet lorem. Vivamus cursus urna porta justo rutrum congue. Aliquam et enim quam. Proin et sollicitudin mi, vitae luctus tortor.</p><p>Proin neque nisl, tempus eu tortor posuere, molestie imperdiet augue. Nullam vel ligula eget ante efficitur bibendum. Fusce convallis, ipsum ac consectetur hendrerit, quam urna convallis nibh, sit amet porttitor purus eros sed lorem. Pellentesque placerat sem eu lorem condimentum, vel dignissim mi tristique.\r\nNullam fringilla tellus massa, vitae pharetra orci euismod nec. Suspendisse blandit faucibus justo et vestibulum. Integer semper enim mattis, rutrum justo a, aliquam risus. Cras porta hendrerit ullamcorper.</p><p>Ut sit amet libero efficitur, vestibulum elit sit amet, dictum diam. Mauris fermentum libero ac luctus maximus. Quisque libero augue, dapibus consectetur ullamcorper eu, venenatis non lacus. Morbi tempus lectus sit amet urna dignissim, id pellentesque orci placerat.\r\nPellentesque eu porta nibh, a convallis turpis. Vestibulum ac feugiat risus. Cras ac augue magna. Nulla facilisi. Praesent non metus at nisi aliquam euismod vitae quis nisl. Quisque placerat viverra nulla, vitae vestibulum nisi placerat vitae. Praesent tempus laoreet tellus, eget gravida lacus convallis ac. Vestibulum lacinia rutrum lectus sit amet lobortis. Integer tempus tincidunt orci nec sagittis.</p>','','two-thirds',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2014-10-27 12:52:44','2014-10-27 12:54:24','eec66eb0-20bd-4907-8399-94890fa9036e');

/*!40000 ALTER TABLE `craft_matrixcontent_article` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_matrixcontent_menu
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_matrixcontent_menu`;

CREATE TABLE `craft_matrixcontent_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `field_externalLink_linkUrl` text COLLATE utf8_unicode_ci,
  `field_externalLink_label` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_matrixcontent_menu_elementId_locale_unq_idx` (`elementId`,`locale`),
  KEY `craft_matrixcontent_menu_locale_fk` (`locale`),
  CONSTRAINT `craft_matrixcontent_menu_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_matrixcontent_menu_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_matrixcontent_menu` WRITE;
/*!40000 ALTER TABLE `craft_matrixcontent_menu` DISABLE KEYS */;

INSERT INTO `craft_matrixcontent_menu` (`id`, `elementId`, `locale`, `field_externalLink_linkUrl`, `field_externalLink_label`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,14,'en_gb',NULL,NULL,'2014-10-27 15:45:13','2014-10-27 15:52:01','67493078-c417-4c53-86e7-da75e65fa5cd'),
	(2,15,'en_gb',NULL,NULL,'2014-10-27 15:46:22','2014-10-27 15:52:01','31332522-9202-4684-9acc-d0f04e152b36'),
	(3,16,'en_gb','https://twitter.com/freeukgen','Twitter','2014-10-27 15:46:22','2014-10-27 15:52:01','070e6fed-e431-4644-80f3-83da2c2f4097'),
	(4,17,'en_gb',NULL,NULL,'2014-10-27 15:57:08','2014-10-27 15:57:47','94441dad-76ef-4641-b60d-7cc506bc0dd6'),
	(7,20,'en_gb',NULL,NULL,'2014-10-27 15:57:08','2014-10-27 15:57:47','25211e5e-35bf-41e0-866a-c94a04506103'),
	(8,23,'en_gb',NULL,NULL,'2014-10-27 15:57:47','2014-10-27 15:57:47','9dadf935-8686-465f-89a3-0f5ce8ddcfa9'),
	(9,24,'en_gb',NULL,NULL,'2014-10-27 15:57:47','2014-10-27 15:57:47','25700b88-5901-49dd-9c05-2629ab192e07');

/*!40000 ALTER TABLE `craft_matrixcontent_menu` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_migrations`;

CREATE TABLE `craft_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pluginId` int(11) DEFAULT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_migrations_version_unq_idx` (`version`),
  KEY `craft_migrations_pluginId_fk` (`pluginId`),
  CONSTRAINT `craft_migrations_pluginId_fk` FOREIGN KEY (`pluginId`) REFERENCES `craft_plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_migrations` WRITE;
/*!40000 ALTER TABLE `craft_migrations` DISABLE KEYS */;

INSERT INTO `craft_migrations` (`id`, `pluginId`, `version`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,NULL,'m000000_000000_base','2014-10-23 14:13:21','2014-10-23 14:13:21','2014-10-23 14:13:21','8a311a30-f879-4bc7-a3e4-425c4e6ad600'),
	(2,NULL,'m140730_000001_add_filename_and_format_to_transformindex','2014-10-23 14:13:21','2014-10-23 14:13:21','2014-10-23 14:13:21','9b672e51-2c22-48f4-bf9a-57312a2d1234'),
	(3,NULL,'m140815_000001_add_format_to_transforms','2014-10-23 14:13:21','2014-10-23 14:13:21','2014-10-23 14:13:21','1f1b2ba0-790a-4820-a2a9-25f37d7e9633'),
	(4,NULL,'m140822_000001_allow_more_than_128_items_per_field','2014-10-23 14:13:21','2014-10-23 14:13:21','2014-10-23 14:13:21','4dbede39-15e9-4128-8a59-0b7f71d48eb1'),
	(5,NULL,'m140829_000001_single_title_formats','2014-10-23 14:13:21','2014-10-23 14:13:21','2014-10-23 14:13:21','fa6dea86-ce7e-4634-8340-8a669d20c2ec'),
	(6,NULL,'m140831_000001_extended_cache_keys','2014-10-23 14:13:21','2014-10-23 14:13:21','2014-10-23 14:13:21','a50adfd6-3c0c-44d7-a6ad-56cbcb63d5c3'),
	(7,NULL,'m140922_000001_delete_orphaned_matrix_blocks','2014-10-23 14:13:21','2014-10-23 14:13:21','2014-10-23 14:13:21','5c883d60-435f-41c1-bf63-92cd0ba04e38'),
	(8,1,'m131228_045200_sproutforms_AddFieldSortOrder','2014-10-23 14:13:36','2014-10-23 14:13:36','2014-10-23 14:13:36','0f38319b-4839-497a-808c-709884fd2365'),
	(9,1,'m131228_120000_sproutForms_addFormRedirectUri','2014-10-23 14:13:36','2014-10-23 14:13:36','2014-10-23 14:13:36','e35487d0-86db-4fdd-872e-f7490c7c1905'),
	(10,6,'m140430_122214_import_ImportHistory','2014-10-23 14:13:46','2014-10-23 14:13:46','2014-10-23 14:13:46','a7f4776f-d6a1-4d54-a8ae-fbd68facf172'),
	(11,6,'m140616_080724_import_saveEntryIdAndVersion','2014-10-23 14:13:46','2014-10-23 14:13:46','2014-10-23 14:13:46','f6ddeccf-e1ec-4529-9cac-156c4a972d99'),
	(12,6,'m140903_075432_import_ImportElements','2014-10-23 14:13:46','2014-10-23 14:13:46','2014-10-23 14:13:46','4676249b-294f-4e6a-a78c-310c432e1d4d');

/*!40000 ALTER TABLE `craft_migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_plugins
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_plugins`;

CREATE TABLE `craft_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `version` char(15) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `settings` text COLLATE utf8_unicode_ci,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_plugins` WRITE;
/*!40000 ALTER TABLE `craft_plugins` DISABLE KEYS */;

INSERT INTO `craft_plugins` (`id`, `class`, `version`, `enabled`, `settings`, `installDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'SproutForms','0.6.0.1',1,NULL,'2014-10-23 14:13:36','2014-10-23 14:13:36','2014-10-23 14:13:36','464abed2-813d-462f-a5b8-49339ac45554'),
	(3,'PimpMyMatrix','1.1',1,'{\"buttonConfig\":\"[{\\\"fieldHandle\\\":\\\"article\\\",\\\"config\\\":[{\\\"blockType\\\":{\\\"handle\\\":\\\"text\\\",\\\"name\\\":\\\"Text\\\"},\\\"group\\\":\\\"Text\\\"},{\\\"blockType\\\":{\\\"handle\\\":\\\"button\\\",\\\"name\\\":\\\"Button\\\"},\\\"group\\\":\\\"Widget\\\"},{\\\"blockType\\\":{\\\"handle\\\":\\\"download\\\",\\\"name\\\":\\\"Download\\\"},\\\"group\\\":\\\"Widget\\\"},{\\\"blockType\\\":{\\\"handle\\\":\\\"embed\\\",\\\"name\\\":\\\"Embed\\\"},\\\"group\\\":\\\"Media\\\"},{\\\"blockType\\\":{\\\"handle\\\":\\\"form\\\",\\\"name\\\":\\\"Form\\\"},\\\"group\\\":\\\"Widget\\\"},{\\\"blockType\\\":{\\\"handle\\\":\\\"heading\\\",\\\"name\\\":\\\"Heading\\\"},\\\"group\\\":\\\"Text\\\"},{\\\"blockType\\\":{\\\"handle\\\":\\\"html\\\",\\\"name\\\":\\\"HTML\\\"},\\\"group\\\":\\\"Media\\\"},{\\\"blockType\\\":{\\\"handle\\\":\\\"image\\\",\\\"name\\\":\\\"Image\\\"},\\\"group\\\":\\\"Media\\\"},{\\\"blockType\\\":{\\\"handle\\\":\\\"quote\\\",\\\"name\\\":\\\"Quote\\\"},\\\"group\\\":\\\"Text\\\"},{\\\"blockType\\\":{\\\"handle\\\":\\\"separator\\\",\\\"name\\\":\\\"Separator\\\"},\\\"group\\\":\\\"Design\\\"}]}]\"}','2014-10-23 14:13:46','2014-10-23 14:13:46','2014-10-23 14:13:47','c3b86992-2a10-4dc0-b509-288541c04b9f'),
	(4,'Fetch','1.0',1,NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','2014-10-23 14:13:46','cb84b803-5d80-41a5-a3a1-5da420c60b44'),
	(5,'Introvert','0.2',1,NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','2014-10-23 14:13:46','32a7629d-1445-44f2-9654-31a91a76d498'),
	(6,'Import','0.8.10',1,NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','2014-10-23 14:13:46','9eea77a9-11c4-4265-baab-43acc7d90e51'),
	(7,'Slugify','1.1',1,NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','2014-10-23 14:13:46','2973d658-12d7-4b20-b59c-404552656bc9'),
	(8,'AuditLog','0.2.2',1,NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','2014-10-23 14:13:46','1f7b56ca-4b89-432c-bac6-d7e43efe03e1'),
	(9,'Anchors','1.0',1,NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','2014-10-23 14:13:46','99eaf00a-41b1-4936-ad2a-e3e413b490ab'),
	(10,'Help','0.2',1,NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','2014-10-23 14:13:46','f5939bc0-7a12-4ae5-a87e-d9d407748ee2'),
	(11,'ButtonBox','1.4',1,NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','2014-10-23 14:13:46','b10638b3-c9b8-40a6-8dbd-d90882e79449'),
	(12,'Toolbox','1.0',1,NULL,'2014-10-23 14:13:46','2014-10-23 14:13:46','2014-10-23 14:13:46','1be66b09-6abd-4b7e-b031-e3e24890df9c');

/*!40000 ALTER TABLE `craft_plugins` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_rackspaceaccess
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_rackspaceaccess`;

CREATE TABLE `craft_rackspaceaccess` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `connectionKey` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `storageUrl` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cdnUrl` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_rackspaceaccess_connectionKey_unq_idx` (`connectionKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_relations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_relations`;

CREATE TABLE `craft_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceLocale` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_relations_fieldId_sourceId_sourceLocale_targetId_unq_idx` (`fieldId`,`sourceId`,`sourceLocale`,`targetId`),
  KEY `craft_relations_sourceId_fk` (`sourceId`),
  KEY `craft_relations_sourceLocale_fk` (`sourceLocale`),
  KEY `craft_relations_targetId_fk` (`targetId`),
  CONSTRAINT `craft_relations_targetId_fk` FOREIGN KEY (`targetId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_relations_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `craft_fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_relations_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_relations_sourceLocale_fk` FOREIGN KEY (`sourceLocale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_relations` WRITE;
/*!40000 ALTER TABLE `craft_relations` DISABLE KEYS */;

INSERT INTO `craft_relations` (`id`, `fieldId`, `sourceId`, `sourceLocale`, `targetId`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,39,6,NULL,7,1,'2014-10-27 12:51:43','2014-10-27 12:51:43','01551a1b-db49-4ce8-a891-7cb665be6fcd'),
	(2,39,6,NULL,8,2,'2014-10-27 12:51:43','2014-10-27 12:51:43','359233fa-7deb-465d-975a-3d22fa3a1fd5'),
	(5,39,10,NULL,7,1,'2014-10-27 12:54:24','2014-10-27 12:54:24','b11a42af-0aa8-4ff4-a4b1-915df5b0df11'),
	(6,39,10,NULL,9,2,'2014-10-27 12:54:24','2014-10-27 12:54:24','acc42938-83c5-44f0-ad48-cec64172bc62'),
	(10,41,15,NULL,2,1,'2014-10-27 15:52:01','2014-10-27 15:52:01','9fdf232e-d48b-4cbc-82a5-de2829387d10'),
	(11,41,14,NULL,5,1,'2014-10-27 15:52:01','2014-10-27 15:52:01','c4c76750-be51-4ae9-a82d-0ef12e2693b9'),
	(14,41,17,NULL,2,1,'2014-10-27 15:57:47','2014-10-27 15:57:47','484f21fa-3bfe-4eed-91ad-4e412873d048'),
	(15,41,23,NULL,22,1,'2014-10-27 15:57:47','2014-10-27 15:57:47','9437d682-30d1-419a-8040-e583ac324afd'),
	(16,41,24,NULL,21,1,'2014-10-27 15:57:47','2014-10-27 15:57:47','07bacdd5-daf1-48c3-979e-3e3dfa2ade1d'),
	(17,41,20,NULL,5,1,'2014-10-27 15:57:47','2014-10-27 15:57:47','74abffd2-4b13-4599-bf14-f639af759907');

/*!40000 ALTER TABLE `craft_relations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_routes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_routes`;

CREATE TABLE `craft_routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locale` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `urlParts` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `urlPattern` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `template` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` tinyint(4) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_routes_urlPattern_unq_idx` (`urlPattern`),
  KEY `craft_routes_locale_idx` (`locale`),
  CONSTRAINT `craft_routes_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_searchindex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_searchindex`;

CREATE TABLE `craft_searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `fieldId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`locale`),
  FULLTEXT KEY `craft_searchindex_keywords_idx` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_searchindex` WRITE;
/*!40000 ALTER TABLE `craft_searchindex` DISABLE KEYS */;

INSERT INTO `craft_searchindex` (`elementId`, `attribute`, `fieldId`, `locale`, `keywords`)
VALUES
	(1,'username',0,'en_gb',' joshangell '),
	(1,'firstname',0,'en_gb',''),
	(1,'lastname',0,'en_gb',''),
	(1,'fullname',0,'en_gb',''),
	(1,'email',0,'en_gb',' josh supercooldesign co uk '),
	(1,'slug',0,'en_gb',''),
	(2,'field',1,'en_gb',' welcome to freeukgenealogy craft dev '),
	(2,'field',2,'en_gb',' it s true this site doesn t have a whole lot of content yet but don t worry our web developers have just installed the cms and they re setting things up for the content editors this very moment soon freeukgenealogy craft dev will be an oasis of fresh perspectives sharp analyses and astute opinions that will keep you coming back again and again '),
	(2,'slug',0,'en_gb',' home '),
	(2,'title',0,'en_gb',' home '),
	(3,'field',2,'en_gb',' craft is the cms that s powering freeukgenealogy craft dev it s beautiful powerful flexible and easy to use and it s made by pixel tonic we can t wait to dive in and see what it s capable of this is even more captivating content which you couldn t see on the news index page because it was entered after a page break and the news index template only likes to show the content on the first page craft a nice alternative to word if you re making a website '),
	(3,'field',3,'en_gb',''),
	(3,'slug',0,'en_gb',''),
	(3,'title',0,'en_gb',' we just installed craft '),
	(4,'field',4,'en_gb',' 0 '),
	(4,'field',5,'en_gb',''),
	(4,'slug',0,'en_gb',''),
	(6,'slug',0,'en_gb',' toot '),
	(6,'title',0,'en_gb',' toot '),
	(7,'slug',0,'en_gb',''),
	(7,'title',0,'en_gb',' data '),
	(8,'slug',0,'en_gb',''),
	(8,'title',0,'en_gb',' something '),
	(9,'slug',0,'en_gb',''),
	(9,'title',0,'en_gb',' else '),
	(6,'field',37,'en_gb',''),
	(6,'field',39,'en_gb',' data something '),
	(6,'field',5,'en_gb',''),
	(6,'field',38,'en_gb',''),
	(6,'field',36,'en_gb',''),
	(10,'field',37,'en_gb',''),
	(10,'field',39,'en_gb',' data else '),
	(10,'field',5,'en_gb',' lorem ipsum dolor sit amet consectetur adipiscing elit vivamus nec enim a nulla laoreet congue pharetra sed mi maecenas placerat euismod elit ac tincidunt morbi varius nisl sit amet cursus pretium lorem erat egestas mi at blandit quam magna non nulla mauris dictum fermentum nisl eu sollicitudin proin consequat neque massa at luctus turpis fringilla sit amet cras placerat ultricies justo ut scelerisque quam suscipit et duis fermentum ullamcorper lorem non elementum nam luctus sagittis elit vel interdum urna pharetra eget integer at diam et felis venenatis egestas nulla consectetur eu turpis quis vulputate nunc facilisis leo sapien sit amet consectetur mi hendrerit non nullam lacinia imperdiet vehicula vestibulum iaculis lacus non lorem vehicula condimentum nulla vitae aliquet lorem vivamus cursus urna porta justo rutrum congue aliquam et enim quam proin et sollicitudin mi vitae luctus tortor proin neque nisl tempus eu tortor posuere molestie imperdiet augue nullam vel ligula eget ante efficitur bibendum fusce convallis ipsum ac consectetur hendrerit quam urna convallis nibh sit amet porttitor purus eros sed lorem pellentesque placerat sem eu lorem condimentum vel dignissim mi tristique nullam fringilla tellus massa vitae pharetra orci euismod nec suspendisse blandit faucibus justo et vestibulum integer semper enim mattis rutrum justo a aliquam risus cras porta hendrerit ullamcorper ut sit amet libero efficitur vestibulum elit sit amet dictum diam mauris fermentum libero ac luctus maximus quisque libero augue dapibus consectetur ullamcorper eu venenatis non lacus morbi tempus lectus sit amet urna dignissim id pellentesque orci placerat pellentesque eu porta nibh a convallis turpis vestibulum ac feugiat risus cras ac augue magna nulla facilisi praesent non metus at nisi aliquam euismod vitae quis nisl quisque placerat viverra nulla vitae vestibulum nisi placerat vitae praesent tempus laoreet tellus eget gravida lacus convallis ac vestibulum lacinia rutrum lectus sit amet lobortis integer tempus tincidunt orci nec sagittis two thirds '),
	(10,'field',38,'en_gb',''),
	(10,'field',36,'en_gb',''),
	(10,'slug',0,'en_gb',' twottle one day might mean something '),
	(10,'title',0,'en_gb',' twottle one day might mean something '),
	(11,'field',6,'en_gb',' lorem ipsum dolor sit amet consectetur adipiscing elit vivamus nec enim a nulla laoreet congue pharetra sed mi maecenas placerat euismod elit ac tincidunt morbi varius nisl sit amet cursus pretium lorem erat egestas mi at blandit quam magna non nulla mauris dictum fermentum nisl eu sollicitudin proin consequat neque massa at luctus turpis fringilla sit amet cras placerat ultricies justo ut scelerisque quam suscipit et duis fermentum ullamcorper lorem non elementum nam luctus sagittis elit vel interdum urna pharetra eget integer at diam et felis venenatis egestas nulla consectetur eu turpis quis vulputate nunc facilisis leo sapien sit amet consectetur mi hendrerit non nullam lacinia imperdiet vehicula vestibulum iaculis lacus non lorem vehicula condimentum nulla vitae aliquet lorem vivamus cursus urna porta justo rutrum congue aliquam et enim quam proin et sollicitudin mi vitae luctus tortor proin neque nisl tempus eu tortor posuere molestie imperdiet augue nullam vel ligula eget ante efficitur bibendum fusce convallis ipsum ac consectetur hendrerit quam urna convallis nibh sit amet porttitor purus eros sed lorem pellentesque placerat sem eu lorem condimentum vel dignissim mi tristique nullam fringilla tellus massa vitae pharetra orci euismod nec suspendisse blandit faucibus justo et vestibulum integer semper enim mattis rutrum justo a aliquam risus cras porta hendrerit ullamcorper ut sit amet libero efficitur vestibulum elit sit amet dictum diam mauris fermentum libero ac luctus maximus quisque libero augue dapibus consectetur ullamcorper eu venenatis non lacus morbi tempus lectus sit amet urna dignissim id pellentesque orci placerat pellentesque eu porta nibh a convallis turpis vestibulum ac feugiat risus cras ac augue magna nulla facilisi praesent non metus at nisi aliquam euismod vitae quis nisl quisque placerat viverra nulla vitae vestibulum nisi placerat vitae praesent tempus laoreet tellus eget gravida lacus convallis ac vestibulum lacinia rutrum lectus sit amet lobortis integer tempus tincidunt orci nec sagittis '),
	(11,'field',7,'en_gb',''),
	(11,'field',8,'en_gb',' two thirds '),
	(11,'slug',0,'en_gb',''),
	(2,'field',4,'en_gb',' 0 '),
	(2,'field',36,'en_gb',''),
	(2,'field',5,'en_gb',''),
	(2,'field',37,'en_gb',''),
	(2,'field',38,'en_gb',''),
	(12,'slug',0,'en_gb',''),
	(13,'slug',0,'en_gb',''),
	(13,'field',40,'en_gb',' home blog https twitter com freeukgen '),
	(12,'field',40,'en_gb',' home blog '),
	(5,'slug',0,'en_gb',' blog '),
	(5,'title',0,'en_gb',' blog '),
	(14,'field',41,'en_gb',' blog '),
	(14,'slug',0,'en_gb',''),
	(15,'field',41,'en_gb',' home '),
	(15,'slug',0,'en_gb',''),
	(16,'field',42,'en_gb',' https twitter com freeukgen '),
	(16,'slug',0,'en_gb',''),
	(16,'field',44,'en_gb',' twitter '),
	(17,'field',41,'en_gb',' home '),
	(17,'slug',0,'en_gb',''),
	(18,'field',44,'en_gb',''),
	(18,'field',42,'en_gb',''),
	(18,'slug',0,'en_gb',''),
	(19,'field',44,'en_gb',''),
	(19,'field',42,'en_gb',''),
	(19,'slug',0,'en_gb',''),
	(20,'field',41,'en_gb',' blog '),
	(20,'slug',0,'en_gb',''),
	(21,'field',4,'en_gb',' 0 '),
	(21,'field',36,'en_gb',''),
	(21,'field',5,'en_gb',''),
	(21,'field',37,'en_gb',''),
	(21,'field',38,'en_gb',''),
	(21,'slug',0,'en_gb',' about '),
	(21,'title',0,'en_gb',' about '),
	(22,'field',4,'en_gb',' 0 '),
	(22,'field',36,'en_gb',''),
	(22,'field',5,'en_gb',''),
	(22,'field',37,'en_gb',''),
	(22,'field',38,'en_gb',''),
	(22,'slug',0,'en_gb',' support '),
	(22,'title',0,'en_gb',' support '),
	(23,'field',41,'en_gb',' support '),
	(23,'slug',0,'en_gb',''),
	(24,'field',41,'en_gb',' about '),
	(24,'slug',0,'en_gb','');

/*!40000 ALTER TABLE `craft_searchindex` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_sections
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sections`;

CREATE TABLE `craft_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('single','channel','structure') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'channel',
  `hasUrls` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `template` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enableVersioning` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_sections_name_unq_idx` (`name`),
  UNIQUE KEY `craft_sections_handle_unq_idx` (`handle`),
  KEY `craft_sections_structureId_fk` (`structureId`),
  CONSTRAINT `craft_sections_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_sections` WRITE;
/*!40000 ALTER TABLE `craft_sections` DISABLE KEYS */;

INSERT INTO `craft_sections` (`id`, `structureId`, `name`, `handle`, `type`, `hasUrls`, `template`, `enableVersioning`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,NULL,'Home','home','single',1,'pages/_homepage',1,'2014-10-23 14:13:22','2014-10-27 15:45:23','5bab0d44-2253-4258-95fd-655a184d207a'),
	(3,1,'Pages','pages','structure',1,'_layouts/main',1,'2014-10-23 14:13:47','2014-10-27 12:54:51','60a46d7c-ffd6-445d-8414-12e9b1d31156'),
	(4,NULL,'Blog','blog','single',1,'blog/_index',1,'2014-10-27 12:42:18','2014-10-27 15:44:59','dde1b267-1b4e-404e-b27e-e394940228f2'),
	(5,NULL,'Blog post','blogPost','channel',1,'blog/_entry',1,'2014-10-27 12:43:48','2014-10-27 15:44:49','267da50b-c8b2-437c-9a21-ab142e7545a2');

/*!40000 ALTER TABLE `craft_sections` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_sections_i18n
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sections_i18n`;

CREATE TABLE `craft_sections_i18n` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `enabledByDefault` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `urlFormat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nestedUrlFormat` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_sections_i18n_sectionId_locale_unq_idx` (`sectionId`,`locale`),
  KEY `craft_sections_i18n_locale_fk` (`locale`),
  CONSTRAINT `craft_sections_i18n_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `craft_sections_i18n_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `craft_sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_sections_i18n` WRITE;
/*!40000 ALTER TABLE `craft_sections_i18n` DISABLE KEYS */;

INSERT INTO `craft_sections_i18n` (`id`, `sectionId`, `locale`, `enabledByDefault`, `urlFormat`, `nestedUrlFormat`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'en_gb',0,'__home__',NULL,'2014-10-23 14:13:22','2014-10-27 12:55:17','5eda9189-0cac-44cd-a038-a02c290f6c71'),
	(3,3,'en_gb',0,'{slug}','{parent.uri}/{slug}','2014-10-23 14:13:47','2014-10-27 12:54:51','184a193d-27aa-4646-a6d1-01a23cdb0a34'),
	(4,4,'en_gb',0,'blog',NULL,'2014-10-27 12:42:18','2014-10-27 12:42:18','651dd37b-7bc7-4aba-908f-fc46d1d03a17'),
	(5,5,'en_gb',0,'blog/{postDate|date(\"Y\")}/{postDate|date(\"m\")}/{postDate|date(\"d\")}/{slug}',NULL,'2014-10-27 12:43:48','2014-10-27 12:43:48','6cf0637a-fa16-4b09-917e-70b40af80ce0');

/*!40000 ALTER TABLE `craft_sections_i18n` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_sessions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sessions`;

CREATE TABLE `craft_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_sessions_uid_idx` (`uid`),
  KEY `craft_sessions_token_idx` (`token`),
  KEY `craft_sessions_dateUpdated_idx` (`dateUpdated`),
  KEY `craft_sessions_userId_fk` (`userId`),
  CONSTRAINT `craft_sessions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_sessions` WRITE;
/*!40000 ALTER TABLE `craft_sessions` DISABLE KEYS */;

INSERT INTO `craft_sessions` (`id`, `userId`, `token`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'6ee1b3881bc89083077a9a1c7cdeb0c85a602f24czozNjoiNDFkOGUwOWYtYzYxZi00NTg2LThkYTUtZTNhNzZmZTk5ZTM3Ijs=','2014-10-23 14:13:22','2014-10-23 14:13:22','2b98360c-4f0d-4413-b317-47306b2d71bf'),
	(2,1,'326ffec73d0376d48c4b4389e57e9bd5925351a5czozNjoiOTczMDM2NjAtM2JkOS00YjI2LWFmMWYtMTJjYjY2ODZiOGRhIjs=','2014-10-27 12:32:06','2014-10-27 12:32:06','bfa6c70a-dd68-4d91-b368-6b568d3b312b'),
	(4,1,'042f545e55ab86c81638df28ae5c73b8b1f520e9czozNjoiMzk3MzMxMTEtNzU3ZS00NjRmLWFiNTktZmRiMTkxMWM4MTlmIjs=','2014-10-27 15:56:49','2014-10-27 15:56:49','79f6d2dd-f38d-4246-9a1b-d9036c9415fc');

/*!40000 ALTER TABLE `craft_sessions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_shunnedmessages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_shunnedmessages`;

CREATE TABLE `craft_shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_shunnedmessages_userId_message_unq_idx` (`userId`,`message`),
  CONSTRAINT `craft_shunnedmessages_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_sproutforms_content
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sproutforms_content`;

CREATE TABLE `craft_sproutforms_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `formId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_sproutforms_content_formId_fk` (`formId`),
  CONSTRAINT `craft_sproutforms_content_formId_fk` FOREIGN KEY (`formId`) REFERENCES `craft_sproutforms_forms` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_sproutforms_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sproutforms_fields`;

CREATE TABLE `craft_sproutforms_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `formId` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(58) COLLATE utf8_unicode_ci NOT NULL,
  `context` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'global',
  `instructions` text COLLATE utf8_unicode_ci,
  `translatable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `validation` text COLLATE utf8_unicode_ci,
  `sortOrder` tinyint(4) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_sproutforms_fields_handle_context_unq_idx` (`handle`,`context`),
  KEY `craft_sproutforms_fields_context_idx` (`context`),
  KEY `craft_sproutforms_fields_formId_fk` (`formId`),
  CONSTRAINT `craft_sproutforms_fields_formId_fk` FOREIGN KEY (`formId`) REFERENCES `craft_sproutforms_forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_sproutforms_forms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_sproutforms_forms`;

CREATE TABLE `craft_sproutforms_forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `redirectUri` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_distribution_list` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_structureelements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_structureelements`;

CREATE TABLE `craft_structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_structureelements_structureId_elementId_unq_idx` (`structureId`,`elementId`),
  KEY `craft_structureelements_root_idx` (`root`),
  KEY `craft_structureelements_lft_idx` (`lft`),
  KEY `craft_structureelements_rgt_idx` (`rgt`),
  KEY `craft_structureelements_level_idx` (`level`),
  KEY `craft_structureelements_elementId_fk` (`elementId`),
  CONSTRAINT `craft_structureelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_structureelements_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `craft_structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_structureelements` WRITE;
/*!40000 ALTER TABLE `craft_structureelements` DISABLE KEYS */;

INSERT INTO `craft_structureelements` (`id`, `structureId`, `elementId`, `root`, `lft`, `rgt`, `level`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,2,NULL,1,1,8,0,'2014-10-27 12:51:26','2014-10-27 12:51:26','492bda9d-941b-432a-ab4a-d3ed518746d9'),
	(2,2,7,1,2,3,1,'2014-10-27 12:51:26','2014-10-27 12:51:26','0d0259ef-8a5a-4772-b946-c671d0fbad99'),
	(3,2,8,1,4,5,1,'2014-10-27 12:51:30','2014-10-27 12:51:30','f87e2b05-badf-4792-b6cc-c910b760fe50'),
	(4,2,9,1,6,7,1,'2014-10-27 12:51:31','2014-10-27 12:51:31','97519627-72bf-44f4-aab0-a51a32d74660'),
	(5,1,NULL,5,1,6,0,'2014-10-27 15:57:18','2014-10-27 15:57:18','73ff1445-ddf7-40d2-8c7e-66718962b3ab'),
	(6,1,21,5,2,3,1,'2014-10-27 15:57:18','2014-10-27 15:57:18','51e390c3-5c8b-46f9-a7ec-3ec7ebab4ae6'),
	(7,1,22,5,4,5,1,'2014-10-27 15:57:24','2014-10-27 15:57:24','03767483-cb69-492d-a49a-70c1f1d602cb');

/*!40000 ALTER TABLE `craft_structureelements` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_structures
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_structures`;

CREATE TABLE `craft_structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `movePermission` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_structures` WRITE;
/*!40000 ALTER TABLE `craft_structures` DISABLE KEYS */;

INSERT INTO `craft_structures` (`id`, `maxLevels`, `movePermission`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,NULL,NULL,'2014-10-23 14:13:47','2014-10-27 12:54:51','9858b9e8-d496-44de-9b14-9c6812bd06cb'),
	(2,1,NULL,'2014-10-27 12:49:01','2014-10-27 12:49:01','f93dc445-3200-48b6-8dee-ad42591d2d6e');

/*!40000 ALTER TABLE `craft_structures` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_systemsettings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_systemsettings`;

CREATE TABLE `craft_systemsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_systemsettings_category_unq_idx` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_systemsettings` WRITE;
/*!40000 ALTER TABLE `craft_systemsettings` DISABLE KEYS */;

INSERT INTO `craft_systemsettings` (`id`, `category`, `settings`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'email','{\"protocol\":\"php\",\"emailAddress\":\"josh@supercooldesign.co.uk\",\"senderName\":\"Free UK Genealogy\"}','2014-10-23 14:13:22','2014-10-23 14:13:22','dc489cfe-720f-42ad-9db2-8b56ccac5d3f');

/*!40000 ALTER TABLE `craft_systemsettings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_taggroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_taggroups`;

CREATE TABLE `craft_taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fieldLayoutId` int(10) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_taggroups_name_unq_idx` (`name`),
  UNIQUE KEY `craft_taggroups_handle_unq_idx` (`handle`),
  KEY `craft_taggroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `craft_taggroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `craft_fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_tags
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_tags`;

CREATE TABLE `craft_tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_tags_name_groupId_unq_idx` (`name`,`groupId`),
  KEY `craft_tags_groupId_fk` (`groupId`),
  CONSTRAINT `craft_tags_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_tags_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_tasks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_tasks`;

CREATE TABLE `craft_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `currentStep` int(11) unsigned DEFAULT NULL,
  `totalSteps` int(11) unsigned DEFAULT NULL,
  `status` enum('pending','error','running') COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_tasks_root_idx` (`root`),
  KEY `craft_tasks_lft_idx` (`lft`),
  KEY `craft_tasks_rgt_idx` (`rgt`),
  KEY `craft_tasks_level_idx` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_templatecachecriteria
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_templatecachecriteria`;

CREATE TABLE `craft_templatecachecriteria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `criteria` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_templatecachecriteria_cacheId_fk` (`cacheId`),
  KEY `craft_templatecachecriteria_type_idx` (`type`),
  CONSTRAINT `craft_templatecachecriteria_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_templatecacheelements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_templatecacheelements`;

CREATE TABLE `craft_templatecacheelements` (
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  KEY `craft_templatecacheelements_cacheId_fk` (`cacheId`),
  KEY `craft_templatecacheelements_elementId_fk` (`elementId`),
  CONSTRAINT `craft_templatecacheelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_templatecacheelements_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `craft_templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_templatecaches
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_templatecaches`;

CREATE TABLE `craft_templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheKey` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `locale` char(12) COLLATE utf8_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `craft_templatecaches_expiryDate_cacheKey_locale_path_idx` (`expiryDate`,`cacheKey`,`locale`,`path`),
  KEY `craft_templatecaches_locale_fk` (`locale`),
  CONSTRAINT `craft_templatecaches_locale_fk` FOREIGN KEY (`locale`) REFERENCES `craft_locales` (`locale`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_tokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_tokens`;

CREATE TABLE `craft_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `route` text COLLATE utf8_unicode_ci,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_tokens_token_unq_idx` (`token`),
  KEY `craft_tokens_expiryDate_idx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_usergroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_usergroups`;

CREATE TABLE `craft_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `handle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_usergroups_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_usergroups_users`;

CREATE TABLE `craft_usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_usergroups_users_groupId_userId_unq_idx` (`groupId`,`userId`),
  KEY `craft_usergroups_users_userId_fk` (`userId`),
  CONSTRAINT `craft_usergroups_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_usergroups_users_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_userpermissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpermissions`;

CREATE TABLE `craft_userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_userpermissions_usergroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpermissions_usergroups`;

CREATE TABLE `craft_userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_usergroups_permissionId_groupId_unq_idx` (`permissionId`,`groupId`),
  KEY `craft_userpermissions_usergroups_groupId_fk` (`groupId`),
  CONSTRAINT `craft_userpermissions_usergroups_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `craft_usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_userpermissions_usergroups_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_userpermissions_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_userpermissions_users`;

CREATE TABLE `craft_userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_userpermissions_users_permissionId_userId_unq_idx` (`permissionId`,`userId`),
  KEY `craft_userpermissions_users_userId_fk` (`userId`),
  CONSTRAINT `craft_userpermissions_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `craft_userpermissions_users_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `craft_userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table craft_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_users`;

CREATE TABLE `craft_users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` char(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preferredLocale` char(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `client` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` enum('active','locked','suspended','pending','archived') COLLATE utf8_unicode_ci DEFAULT 'pending',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIPAddress` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(4) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `verificationCode` char(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passwordResetRequired` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `craft_users_username_unq_idx` (`username`),
  UNIQUE KEY `craft_users_email_unq_idx` (`email`),
  KEY `craft_users_verificationCode_idx` (`verificationCode`),
  KEY `craft_users_uid_idx` (`uid`),
  KEY `craft_users_preferredLocale_fk` (`preferredLocale`),
  CONSTRAINT `craft_users_preferredLocale_fk` FOREIGN KEY (`preferredLocale`) REFERENCES `craft_locales` (`locale`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `craft_users_id_fk` FOREIGN KEY (`id`) REFERENCES `craft_elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_users` WRITE;
/*!40000 ALTER TABLE `craft_users` DISABLE KEYS */;

INSERT INTO `craft_users` (`id`, `username`, `photo`, `firstName`, `lastName`, `email`, `password`, `preferredLocale`, `admin`, `client`, `status`, `lastLoginDate`, `lastLoginAttemptIPAddress`, `invalidLoginWindowStart`, `invalidLoginCount`, `lastInvalidLoginDate`, `lockoutDate`, `verificationCode`, `verificationCodeIssuedDate`, `unverifiedEmail`, `passwordResetRequired`, `lastPasswordChangeDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'joshangell',NULL,NULL,NULL,'josh@supercooldesign.co.uk','$2a$13$NPmiJfdncrn8EDo97py40.VDGZ5k5dgcWfM3tCaGSq2.l6wUoxL5q',NULL,1,0,'active','2014-10-27 15:56:49','127.0.0.1',NULL,NULL,'2014-10-27 15:56:45',NULL,NULL,NULL,NULL,0,'2014-10-23 14:13:21','2014-10-23 14:13:21','2014-10-27 15:56:49','e017461c-4eca-4f6e-90a2-653663da1a74');

/*!40000 ALTER TABLE `craft_users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craft_widgets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craft_widgets`;

CREATE TABLE `craft_widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `sortOrder` tinyint(4) DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craft_widgets_userId_fk` (`userId`),
  CONSTRAINT `craft_widgets_userId_fk` FOREIGN KEY (`userId`) REFERENCES `craft_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `craft_widgets` WRITE;
/*!40000 ALTER TABLE `craft_widgets` DISABLE KEYS */;

INSERT INTO `craft_widgets` (`id`, `userId`, `type`, `sortOrder`, `settings`, `enabled`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'RecentEntries',1,NULL,1,'2014-10-23 14:13:25','2014-10-23 14:13:25','2dd980f1-d30a-4e94-bb86-a4d28828ac14'),
	(2,1,'GetHelp',2,NULL,1,'2014-10-23 14:13:25','2014-10-23 14:13:25','c33e62dc-0ce0-42ec-b749-0cedaeefd682'),
	(3,1,'Updates',3,NULL,1,'2014-10-23 14:13:25','2014-10-23 14:13:25','09addb4b-3d80-4211-8629-140257a8ac60'),
	(4,1,'Feed',4,'{\"url\":\"http:\\/\\/feeds.feedburner.com\\/blogandtonic\",\"title\":\"Blog & Tonic\"}',1,'2014-10-23 14:13:25','2014-10-23 14:13:25','718ec477-1a13-4744-9021-5adfc8dbae4d');

/*!40000 ALTER TABLE `craft_widgets` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
